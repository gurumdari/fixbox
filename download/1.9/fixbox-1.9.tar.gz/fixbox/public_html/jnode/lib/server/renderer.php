<?php
require_once 'autoload.php';

$jnode = new \Gurumdari\Jnode();
$jnode->registMods();
$jnode->checkHTML5();

$request_uri_only = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);

if (__FILE__ == $jnode::$HTML_HOME.$request_uri_only) {
	$jnode->sendError(404);
} else {
	$template   = 'html';
	if (isset($_GET['template']))  $template = $_GET['template'];

	$page_id    = explode('/$/', $request_uri_only)[0];
	$path_index = strrpos($page_id, '/');
	$ext_index  = strrpos($page_id, '.');

	if (($ext_index === false) || ($path_index > $ext_index)) {
		if (substr($page_id, -1) == '/') {
			$page_id = $page_id."index";
		} else {
			$page_id = "$page_id/index";
		}
	} else {
		$template_ext  = ".$template";
		$template_exts = explode('.', strtolower($template));
		
		$available_extension_list = [];

		array_push($available_extension_list, ".$template_exts[0]");

		if (count($template_exts) == 2) {
			array_push($available_extension_list, ".$template_exts[1]");
		}

		array_push($available_extension_list, '.php', '.html', '.htm');

		if (array_search(strtolower(substr($page_id, $ext_index)), $available_extension_list) === false) {
			$page_id = "$page_id/index";
		} else {
			$page_id = substr($page_id, 0, $ext_index);
		}
	}

	$jnode->requirePage($page_id, $template);
}