<?php
require_once 'autoload.php';

$jnode = new \Gurumdari\Jnode();
$jnode->registMods();

$request_uri_only = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);

if (__FILE__ == $jnode::$HTML_HOME.$request_uri_only) {
	$jnode->sendError(404);
} else if ($request_uri_only == '/jnode/proxy/frontend_dataset.js') {
	require 'frontend_dataset.php';
} else {
	$content_type = 'text/plain';
	$minify       = true;

	if (array_key_exists('content-type', $_REQUEST)) {
		$content_type = strtolower($_REQUEST['content-type']);
	} else {
		$extension = strtolower(pathinfo($request_uri_only)["extension"]);

		if      ($extension == 'css'   )  $content_type = 'text/css';
		else if ($extension == 'less'  )  $content_type = 'text/css';
		else if ($extension == 'js'    )  $content_type = 'text/javascript';
		else if ($extension == 'coffee')  $content_type = 'text/javascript';
		else if ($extension == 'ts'    )  $content_type = 'text/javascript';
	}

	if (array_key_exists('minify', $_REQUEST)) {
		if (strtolower($_REQUEST['minify']) === 'false') {
			$minify = false;
		}
	}

	$options = [
		'content_type' => $content_type,
		'minify'       => $minify
	];

	if ($content_type == 'text/javascript') {
		if ($extension == 'ts')  $options['ts_target'] = 'esnext';

		if (array_key_exists('target', $_REQUEST) && strtolower($_REQUEST['target']) == 'es5') {
			if ($jnode::$PRECOMPILE) {  // Because all browsers use precompiled files.
				$options['ts_target'] = 'es5';
			} else {
				$user_agent = '';

				// When accessing URL Open, there may be no user-agent.
				if (array_key_exists('HTTP_USER_AGENT', $_SERVER))  $user_agent = $_SERVER['HTTP_USER_AGENT'];

				if (strpos($user_agent, 'Trident') || strpos($user_agent, 'MSIE')) {
					$options['ts_target'] = 'es5';
				}
			}
		}
	}

	$jnode->transcompileURI($request_uri_only, $options);
}