<?php
require_once 'autoload.php';

$jnode = new \Gurumdari\Jnode();
$jnode->checkHTML5();

$request_uri_only = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);

if (__FILE__ == $jnode::$HTML_HOME.$request_uri_only) {
	$jnode->sendError(404);
} else {
	$status_code = 500;

	if (isset($_GET['status']))  $status_code = intVal($_GET['status']);
	if ($status_code == 0)       $status_code = 500;

	if (($status_code == 404) && ($request_uri_only == "/")) {
		// $jnode->registMods();
		// $jnode->requirePage('/fixbox/index', 'html');
		header('Location: /fixbox');
	} else if (($status_code == 404) && ($request_uri_only == '/index.html')) {
		if (file_exists($jnode::$HTML_HOME.'/index.php')) {
			header('Location: '.str_replace('/index.html', '/', $_SERVER['REQUEST_URI']));
		} else {
			header('Location: /fixbox');
		}
	} else {
		$jnode->sendError($status_code);
	}
}