<?php
function updateFixBox($fixBox, $jnode, $upload_dir, $fixbox_config, $xuz_conf) {
	$public_html_dir   = $upload_dir."/patch/public_html";
	$protected_cgi_dir = $upload_dir."/patch/protected_cgi";
	$fixbox_php        = $protected_cgi_dir."/mods/FixBox.php";
	$upgrade_php       = $protected_cgi_dir."/template/ajax/settings/upgrade.php";

	$exist_fixbox_php  = file_exists($fixbox_php);
	$exist_upgrade_php = file_exists($upgrade_php);

	if (file_exists($public_html_dir)) {
		$fixBox->moveFile($public_html_dir, $jnode::$HTML_HOME);
	}

	if (file_exists($protected_cgi_dir)) {
		if ($exist_fixbox_php )  rename($fixbox_php , $upload_dir."/patch/FixBox.php");
		if ($exist_upgrade_php)  rename($upgrade_php, $upload_dir."/patch/upgrade.php");

		$fixBox->moveFile($protected_cgi_dir, $jnode::$CGI_HOME);
	}

	// DB Update
	if (file_exists($upload_dir."/patch/db_update.php")) {
		require_once $upload_dir."/patch/db_update.php";
	}

	$fixbox_config["system"]["version"] = $xuz_conf["version"]["released"];
	$fixBox->setConfig($fixbox_config);

	foreach ($xuz_conf["removed"]["public_html"] as $removed_file) {
		if (file_exists($jnode::$HTML_HOME."/".$removed_file))  $fixBox->deleteFile($jnode::$HTML_HOME."/".$removed_file);
	}

	foreach ($xuz_conf["removed"]["protected_cgi"] as $removed_file) {
		if (file_exists($jnode::$CGI_HOME."/".$removed_file))  $fixBox->deleteFile($jnode::$CGI_HOME."/".$removed_file);
	}

	if ($exist_fixbox_php)  rename($upload_dir."/patch/FixBox.php", $jnode::$CGI_HOME."/protected_cgi/mods/FixBox.php");

	return !$exist_upgrade_php;
}

$fixBox = new \Gurumdari\FixBox();
$i18n   = $fixBox->getI18n();

$upload_dir  = $jnode::$TEMPLATE_PATH."/config/xuz";
$upload_file = $upload_dir."/".basename($_FILES["xuz"]['name']);
$remove_xuz  = true;

mkdir($upload_dir, 0775);

if (move_uploaded_file($_FILES['xuz']['tmp_name'], $upload_file) === true) {
	$zip = new \ZipArchive();

	if ($zip->open($upload_file) === true) {
		$zip->extractTo($upload_dir);
		$zip->close();

		$xuz_json_file = $upload_dir."/patch/xuz.json";

		if (file_exists($xuz_json_file)) {
			$fixbox_config = $fixBox->getConfig();
			$cur_version   = $fixbox_config["system"]["version"];

			$json_string = file_get_contents($xuz_json_file);
			$xuz_conf = json_decode($json_string, true);

			if ($xuz_conf["version"]["available"] == $cur_version) {
				$remove_xuz = updateFixBox($fixBox, $jnode, $upload_dir, $fixbox_config, $xuz_conf);
			} else {
				$fixBox->deleteFile($upload_dir);
				throw new \Exception(str_replace("\${available}", $xuz_conf["version"]["available"], $i18n["alert"]["available_xuz"]));
			}
		} else {
			$fixBox->deleteFile($upload_dir);
			throw new \Exception(i18n["alert"]["invalid_xuz"]);
		}
	} else {
		$fixBox->deleteFile($upload_dir);
		throw new \Exception(i18n["alert"]["invalid_xuz"]);
	}
} else {
	$fixBox->deleteFile($upload_dir);
	throw new \Exception(i18n["alert"]["invalid_xuz"]);
}

if ($remove_xuz)  $fixBox->deleteFile($upload_dir);