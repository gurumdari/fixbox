<?php
$fixBox = new \Gurumdari\FixBox();
$fixBox->setDomainAtRainloop($jnode_jparam["domain_name"]);