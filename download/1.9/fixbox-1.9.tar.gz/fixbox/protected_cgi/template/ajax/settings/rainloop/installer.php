<?php
$commands = [
	$jnode::$TEMPLATE_PATH."/config/rainloop/installer.sh",
	$jnode::$HTML_HOME
];

$bridge = new \Gurumdari\CommandBridge();
$result = $bridge->call($commands);

file_get_contents($_SERVER["REQUEST_SCHEME"]."://".$_SERVER["HTTP_HOST"]);

$jnode_dataset = [
	"message" => $result,
	"webmail_domains" => file_exists($jnode::$HTML_HOME."/data/_data_/_default_/domains")
];