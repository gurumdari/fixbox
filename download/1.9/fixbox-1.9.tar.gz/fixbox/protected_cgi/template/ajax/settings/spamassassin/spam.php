<?php
$fixBox = new \Gurumdari\FixBox();
$whitelist = $jnode_jparam["whitelist"];
$blacklist = $jnode_jparam["blacklist"];
$fixBox->setWhiteBlackListAtSpamassassin($whitelist, $blacklist);