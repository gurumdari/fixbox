<?php
$fixBox = new \Gurumdari\FixBox();
$spamassassin_score = $jnode_jparam["spamassassin_score"];
$fixBox->setScoreAtSpamassassin($spamassassin_score);