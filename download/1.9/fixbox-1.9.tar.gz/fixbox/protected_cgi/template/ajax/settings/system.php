<?php
$config_name  = $jnode_jparam["name"];
$config_value = $jnode_jparam["value"];

$fixBox        = new \Gurumdari\FixBox();
$fixbox_config = $fixBox->getConfig();

if ($config_name == "system") {
	$fixbox_config["system"]["lang"]  = $config_value[0];
	$fixbox_config["system"]["theme"] = $config_value[1];
} else if ($config_name == "antispam_settings_file") {
	$fixbox_config["system"]["score_file"]     = $config_value[0];
	$fixbox_config["system"]["whitelist_file"] = $config_value[1];
	$fixbox_config["system"]["blacklist_file"] = $config_value[2];
} else {
	$fixbox_config["system"][$config_name] = $config_value;
}

$fixBox->setConfig($fixbox_config);

if ($config_name == "system") {
	$jnode_dataset = $fixBox->getI18n();
} else if (($config_name == "integrate_rainloop") && isset($jnode_jparam["domain_name"])) {
	if (!file_exists($jnode::$HTML_HOME."/data/_data_/_default_/domains/".$jnode_jparam["domain_name"].".ini")) {
		$jnode_dataset = [
			"not_integrate" => empty($config_value) ? false : true
		];
	}
} else if ($config_name == "antispam_settings_file") {
	$jnode_dataset = [
		"score_file_writable"     => false,
		"whitelist_file_writable" => false,
		"blacklist_file_writable" => false
	];

	$score_file     = $config_value[0];
	$whitelist_file = $config_value[1];
	$blacklist_file = $config_value[2];

	if ($score_file[0]     != "/")  $score_file     = $jnode::$TEMPLATE_PATH."/config/".$score_file;
	if ($whitelist_file[0] != "/")  $whitelist_file = $jnode::$TEMPLATE_PATH."/config/".$whitelist_file;
	if ($blacklist_file[0] != "/")  $blacklist_file = $jnode::$TEMPLATE_PATH."/config/".$blacklist_file;

	$jnode_dataset["score_file_exists"]     = file_exists($score_file);
	$jnode_dataset["whitelist_file_exists"] = file_exists($whitelist_file);
	$jnode_dataset["blacklist_file_exists"] = file_exists($blacklist_file);

	if ($jnode_dataset["score_file_exists"]) {
		// $jnode_dataset["score_file_writable"] = (decoct(fileperms($score_file) & 0777) % 10 % 4) > 1;
		$jnode_dataset["score_file_writable"] = is_writable($score_file);

		if ($jnode_dataset["score_file_writable"]) {
			$spamassassin_score = $fixBox->getScoreFromSpamassassin();
			if ($spamassassin_score == "0.0")  $fixBox->setScoreAtSpamassassin("5.0");
		}
	}

	if ($jnode_dataset["whitelist_file_exists"]) {
		$jnode_dataset["whitelist_file_writable"] = is_writable($whitelist_file);
	}

	if ($jnode_dataset["blacklist_file_exists"]) {
		$jnode_dataset["blacklist_file_writable"] = is_writable($blacklist_file);
	}
}