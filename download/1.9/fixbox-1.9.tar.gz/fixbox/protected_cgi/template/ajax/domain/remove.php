<?php
$fixBox    = new \Gurumdari\FixBox();
$options   = $fixBox->getPDOConf();
$d_options = $options["domains"];
$u_options = $options["users"];
$a_options = $options["aliases"];

$alias_query = <<<"EOT"
DELETE FROM `{$a_options["table_name"]}`
 WHERE `{$a_options["domain_id"]}` = :domain_id
EOT;

$user_query = <<<"EOT"
DELETE FROM `{$u_options["table_name"]}`
 WHERE `{$u_options["domain_id"]}` = :domain_id
EOT;

$domain_query = <<<"EOT"
DELETE FROM `{$d_options["table_name"]}`
 WHERE `{$d_options["domain_id"]}` = :domain_id
EOT;

$sort_query = null;

if (isset($d_options["domain_sort"])) {
	$sort_query = <<<"EOT"
UPDATE `{$d_options["table_name"]}`
   SET `{$d_options["domain_sort"]}` = `{$d_options["domain_sort"]}` - 1
 WHERE `{$d_options["domain_sort"]}` >
       (SELECT `{$d_options["domain_sort"]}`
          FROM (SELECT `{$d_options["domain_sort"]}`
                  FROM `{$d_options["table_name"]}`
                 WHERE `{$d_options["domain_id"]}` = :domain_id) AS sort)
EOT;
}

$params = [
	":domain_id" => $jnode_jparam["domain_id"]
];

$fixBox->deleteTableDomain($alias_query, $user_query, $domain_query, $sort_query, $params);

$domain_ini_file = $jnode::$HTML_HOME."/data/_data_/_default_/domains/".$jnode_jparam["domain_name"].".ini";

if (file_exists($domain_ini_file)) {
	unlink($domain_ini_file);
}