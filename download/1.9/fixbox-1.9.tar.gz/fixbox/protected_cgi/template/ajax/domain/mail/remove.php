<?php
$fixBox    = new \Gurumdari\FixBox();
$options   = $fixBox->getPDOConf();
$u_options = $options["users"];
$a_options = $options["aliases"];

$alias_query = <<<"EOT"
DELETE FROM `{$a_options["table_name"]}`
 WHERE `{$a_options["domain_id"]}` = :domain_id
   AND `{$a_options["source_email"]}` = :email
EOT;

$user_query = <<<"EOT"
DELETE FROM `{$u_options["table_name"]}`
 WHERE `{$u_options["domain_id"]}` = :domain_id
   AND `{$u_options["email"]}` = :email
EOT;

$params = [
	":domain_id" => $jnode_jparam["domain_id"],
	":email" => $jnode_jparam["email"]
];

$fixBox->deleteTableUser($alias_query, $user_query, $params);