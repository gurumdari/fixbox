<?php
$fixBox    = new \Gurumdari\FixBox();
$d_options = $fixBox->getPDOConf("domains");

$query = <<<"EOT"
UPDATE `{$d_options["table_name"]}`
   SET `{$d_options["domain_sort"]}` = :domain_sort
 WHERE `{$d_options["domain_id"]}` = :domain_id
EOT;

$fixBox->sortTableDomain($query, $jnode_jparam["domain_ids"]);