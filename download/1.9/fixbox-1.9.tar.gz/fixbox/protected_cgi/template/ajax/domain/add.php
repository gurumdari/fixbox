<?php
$fixBox    = new \Gurumdari\FixBox();
$d_options = $fixBox->getPDOConf("domains");

$sort_query = null;

if (isset($d_options["domain_sort"])) {
	$sort_query = <<<"EOT"
SELECT MAX(`{$d_options["domain_sort"]}`) AS max_sort
  FROM `{$d_options["table_name"]}`
EOT;

	$insert_query = <<<"EOT"
INSERT INTO `{$d_options["table_name"]}`
       (`{$d_options["domain_name"]}`, `{$d_options["domain_sort"]}`)
VALUES (:domain_name, :domain_sort)
EOT;
} else {
	$insert_query = <<<"EOT"
INSERT INTO `{$d_options["table_name"]}`
       (`{$d_options["domain_name"]}`)
VALUES (:domain_name)
EOT;
}

$params = [
	":domain_name" => $jnode_jparam["domain_name"]
];

$id_query = <<<"EOT"
SELECT MAX(`{$d_options["domain_id"]}`) AS domain_id
  FROM `{$d_options["table_name"]}`
EOT;

try {
	$vhost01 = '/var/mail/vhosts/'.$jnode_jparam["domain_name"];
	$vhost02 = '/var/mail/'.$jnode_jparam["domain_name"];
	$created_vhost = null;

	if      (file_exists($vhost01))  $created_vhost = $vhost01;
	else if (file_exists($vhost02))  $created_vhost = $vhost02;

	if ($created_vhost == null) {
		$i18n = $fixBox->getI18n();

		$message = str_replace("\${vhost01}", $vhost01, $i18n["notice"]["notexist_vhost_dir"]);
		$message = str_replace("\${vhost02}", $vhost02, $message);

		throw new \Exception($message);
	} else {
		if (posix_getpwuid(fileowner($created_vhost))["name"] == "vmail") {
			$domain_id = $fixBox->insertTableDomain($insert_query, $id_query, $sort_query, $params);

			$jnode_dataset = [
				"domain_id" => $domain_id
			];

			if ($jnode_jparam["integrate_rainloop"]) {
				if (!file_exists($jnode::$HTML_HOME."/data/_data_/_default_/domains/".$jnode_jparam["domain_name"].".ini")) {
					$fixBox->setDomainAtRainloop($jnode_jparam["domain_name"]);
				}
			}
		} else {
			$i18n = $fixBox->getI18n();
			throw new \Exception(str_replace("\${created_vhost}", $created_vhost, $i18n["notice"]["invalid_vhost_dir_owner"]));
		}
	}
} catch(\Exception $e) {
	$error_message = $e->getMessage();

	if (strrpos($e->getMessage(), "Duplicate") > 0) {
		$jnode->sendError(409);
	} else {
		throw $e;
	}
}