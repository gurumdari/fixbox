$content$.domain.mail.edit = {
	service: function() {
		var that = this;

		$jnode$.requireControllers(["dataframe", "winup#dataframe"], {caller:that.conf}, function() {
			$controller$.dataframe.service({
				fixedLayout: true,
				names: [ "Aliases" ],
				height: 178
			});

			var selectedRow  = document.querySelector("aside.grid > div > table > tbody > tr.selected");
			var aliasCell    = selectedRow.lastElementChild;
			var aliasSpan    = aliasCell.firstElementChild;
			var aliasesValue = aliasSpan.firstChild.nodeValue;

			if (aliasesValue) {
				$controller$.dataframe.setColumnVector([aliasesValue.split(", ")]);
			}

			var updateButton = document.mailForm.querySelector("form > ul.submit > li > button:first-child");
			var removeButton = updateButton.nextElementSibling;

			updateButton.addEventListener("click", function(event) {
				var alertMessage = null;
				var alertLi      = this.parentNode.previousElementSibling;

				var params = {
					domain_id:       that.conf.domain_id,
					source_email:    that.conf.email,
					new_destination: []
				};

				var columnValues = $controller$.dataframe.getColumnVector();

				if (columnValues) {
					params.new_destination = columnValues[0].map(function(entry) {
						return entry.trim();
					});
				}

				var emailIndex = params.new_destination.indexOf(params.source_email);

				if (emailIndex > -1) {
					alertMessage = i18n.alert.same_mail_account;
					document.querySelector("aside.dataframe > div:nth-child(2) > div:first-child > table > tbody > tr:nth-child(" + (emailIndex + 1) + ") > td > input[type='text']").select();
				} else {
					for (var i = 0; i < params.new_destination.length; i++) {
						if (params.new_destination[i] && (params.new_destination[i].search(/^(([^<>()\[\]\\.,;:\s@*"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/) < 0)) {
							alertMessage = i18n.alert.invalid_aliases;
							document.querySelector("aside.dataframe > div:nth-child(2) > div:first-child > table > tbody > tr:nth-child(" + (i + 1) + ") > td > input[type='text']").select();
							break;
						}
					}
				}

				if (alertMessage) {
					alertLi.innerHTML = alertMessage;
				} else {
					params.new_destination = params.new_destination.filter(function(entry) {
						return entry != "";
					});

					var newDestination = params.new_destination.filter(function(entry, index, self) {
						return index == self.indexOf(entry);
					}).sort();

					function addMail(params) {
						$controller$.loading.show();
						$controller$.dataframe.clear();
						$controller$.dataframe.setColumnVector([params.new_destination]);

						alertLi.innerHTML = "";

						$jnode$.ajax.service({
							"url":      "/ajax/domain/mail/update.json",
							"method":   "POST",
							"datatype": "json",
							"headers": {
								"Content-Type": "application/json",
								"Accept":       "application/json"
							},
							"params": params,
							"success": function(response) {
								var aliasCount = params.new_destination.length;
								aliasCell.setAttribute("class", aliasCount > 0 ? aliasCount : "");
								aliasSpan.firstChild.nodeValue = params.new_destination.join(", ");
								$controller$.grid.clear("thead");

								$controller$.winup.close();
								$controller$.loading.hide();
							},
							"error": function(error) {
								$jnode$.ajax.alertError(error);
								$controller$.loading.hide();
							}
						});
					}

					if (params.new_destination.length == newDestination.length) {
						params.new_destination = newDestination;
						addMail(params);
					} else {
						$controller$.prompt.confirm(i18n.alert.duplicate_email_in_aliases, function(close) {
							params.new_destination = newDestination;
							addMail(params);
							close();
						}, null, 1);
					}
				}
			}, false);

			removeButton.addEventListener("click", function(event) {
				$controller$.prompt.confirm(i18n.alert.confirm_remove_mail_account, function(close) {
					$controller$.loading.show();

					$jnode$.ajax.service({
						"url":      "/ajax/domain/mail/remove.json",
						"method":   "POST",
						"datatype": "json",
						"headers": {
							"Content-Type": "application/json",
							"Accept":       "application/json"
						},
						"params": {
							domain_id: that.conf.domain_id,
							email:     that.conf.email
						},
						"success": function(response) {
							selectedRow.parentNode.removeChild(selectedRow);

							mailEditButton.disabled = true;
							mailPasswordButton.disabled = true;

							$controller$.winup.close();
							$controller$.loading.hide();
						},
						"error": function(error) {
							$jnode$.ajax.alertError(error);
							$controller$.loading.hide();
						}
					});

					close();
				}, null, 2);
			}, false);
		});
	}
};