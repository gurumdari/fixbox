$content$.domain.mails = {
	appendMailRow: function(mailTbody, mailData) {
		var aliases    = mailData.aliases;
		var aliasCount = 0;
		if (aliases)  aliasCount = aliases.split(", ").length;
		else          aliases = "";

		var row = document.createElement("tr");
		row.setAttribute("id", mailData.email);
		mailTbody.appendChild(row);

		var accountCell = row.insertCell(0);
		accountCell.appendChild(document.createTextNode(mailData.email.split("@")[0]));

		var aliasSpan = document.createElement("span");
		aliasSpan.appendChild(document.createTextNode(aliases));

		var aliasCell = row.insertCell(1);
		aliasCell.setAttribute("class", aliasCount > 0 ? aliasCount : "");
		aliasCell.appendChild(aliasSpan);

		row.addEventListener("click", function(event) {
			var selectedRow = mailTbody.querySelector("tbody > tr.selected");
			if (selectedRow)  selectedRow.removeAttribute("class");

			this.setAttribute("class", "selected");
			mailEditButton.disabled     = false;
			mailPasswordButton.disabled = false;
		}, false);
	},

	resize: function(event) {
		var windowWidth = window.innerWidth;

		if (windowWidth > 736) {
			var notificationHeight = 0;
			var notificationNode   = document.querySelector("body > section > article > div.article > div.notification:not(.hidden)");

			if (notificationNode)  notificationHeight = notificationNode.offsetHeight + 10;

			if ($controller$.grid)  $controller$.grid.resize(null, window.innerHeight - notificationHeight - 108);
		} else {
			if ($controller$.grid)  $controller$.grid.removeHeight();
		}

		if ($controller$.grid)  $controller$.grid.resizeScrollButtons();
	},

	service: function() {
		$controller$.loading.show();
		$jnode$.pushHistory(this.conf);

		var that = this;

		document.querySelector("body > section > header > ul > li:nth-child(2)").firstChild.nodeValue = this.conf.domain_name;
		mailEditButton.disabled     = true;
		mailPasswordButton.disabled = true;

		var notificationNode   = document.querySelector("body > section > article > div.article > div.notification");
		var notHiddenNodeCount = notificationNode.querySelectorAll("div > div:not(.hidden)").length;

		if (notHiddenNodeCount > 0) {
			notificationNode.setAttribute("class", "notification");
		}

		function changeLang() {
			if (that.conf.reflect) {
				$jnode$.requireContent("popup", "/settings", {
					widthP:   100,
					heightP:  100,
					maxWidth: 800,
					tab_id:   that.conf.reflect
				});
			} else {
				$controller$.loading.hide();
			}
		}

		if (this.conf.domain_id != null) {
			mailAddButton.disabled = false;

			$jnode$.requireController("grid", {caller:that.conf}).on(function() {
				$controller$.grid.service({sortable:true});

				window.addEventListener("resize", that.resize, false);
				that.resize();

				var mailList  = that.dataset.mail_list;
				var mailTbody = document.querySelector("aside.grid > div > table > tbody");

				for (var i = 0; i < mailList.length; i++) {
					that.appendMailRow(mailTbody, mailList[i]);
				}

				if (that.conf.email != null) {
					mailTbody.querySelector("tbody > tr[id='" + that.conf.email + "']").click();
				}

				changeLang();
			});
		} else {
			changeLang();
		}

		if ($dataset$.plain_password) {
			notificationNode.querySelector("div.notification > div.plain_password > a").addEventListener("click", function(event) {
				if (swappingButton.getAttribute("class") == "unfolding")  swappingButton.click();

				$jnode$.requireContent("popup", "/settings", {
					widthP:   100,
					heightP:  100,
					maxWidth: 800,
					tab_id:   "/settings/admin"
				});
			}, false);
		}

		if ($dataset$.loaded_pdo && $dataset$.not_set_database) {
			notificationNode.querySelector("div.notification > div.not_set_database > a").addEventListener("click", function(event) {
				if (swappingButton.getAttribute("class") == "unfolding")  swappingButton.click();

				$jnode$.requireContent("popup", "/settings", {
					widthP:   100,
					heightP:  100,
					maxWidth: 800,
					tab_id:   "/settings/account"
				});
			}, false);
		}

		notificationNode.querySelector("div.notification > div.not_integrate > a").addEventListener("click", function(event) {
			$controller$.loading.show();

			var notIntegrateNode = this.parentNode;

			$jnode$.ajax.service({
				"url":      "/ajax/settings/rainloop/integrator.json",
				"method":   "POST",
				"datatype": "json",
				"headers": {
					"Content-Type": "application/json",
					"Accept":       "application/json"
				},
				"params": {
					domain_name: that.conf.domain_name
				},
				"success": function(response) {
					notIntegrateNode.setAttribute("class", "not_integrate hidden");

					var notificationNode = notIntegrateNode.parentNode;
					var notHiddenNodeCount = notificationNode.querySelectorAll("div > div:not(.hidden)").length;

					if (notHiddenNodeCount == 0) {
						notificationNode.setAttribute("class", "notification hidden");
					}

					$content$.domain.mails.resize();
					$controller$.loading.hide();
				},
				"error": function(error) {
					$jnode$.ajax.alertError(error);
					$controller$.loading.hide();
				}
			});
		}, false);
	},

	unload: function() {
		if (this.conf.domain_id != null)  window.removeEventListener("resize", this.resize, false);
	}
};