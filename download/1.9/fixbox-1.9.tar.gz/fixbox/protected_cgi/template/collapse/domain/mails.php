<?php
if (isset($_POST["domain_id"])) {
	$fixBox = new \Gurumdari\FixBox();
	$options   = $fixBox->getPDOConf();
	$u_options = $options["users"];
	$a_options = $options["aliases"];
	$settings  = $fixBox->getConfig()["system"];

	$query = <<<"EOT"
SELECT users.`{$u_options["email"]}` AS email
     , GROUP_CONCAT(`{$a_options["destination_email"]}` ORDER BY `{$a_options["destination_email"]}` ASC SEPARATOR ', ') AS aliases
  FROM `{$u_options["table_name"]}` users
  LEFT JOIN `{$a_options["table_name"]}` aliases ON (aliases.`{$a_options["domain_id"]}` = :domain_id AND aliases.`{$a_options["source_email"]}` = users.`{$u_options["email"]}`)
 WHERE users.`{$u_options["domain_id"]}` = :domain_id
 GROUP BY users.`{$u_options["email"]}`
 ORDER BY SUBSTRING_INDEX(users.`{$u_options["email"]}`, '@', 1) ASC
EOT;

	$params = [
		":domain_id" => $_POST["domain_id"]
	];

	$jnode_dataset = [
		"mail_list" => []
	];

	try {
		$jnode_dataset["mail_list"] = $fixBox->selectRowList(null, $query, $params);
	} catch (\Exception $e) {
		$jnode_dataset["db_error"] = $e->getMessage();

		error_log("FixBox Notice: ".$jnode_dataset["db_error"]);
	}

	if ($settings["integrate_rainloop"] && !file_exists($jnode::$HTML_HOME."/data/_data_/_default_/domains/".$_POST["domain_name"].".ini")) {
		$jnode_dataset["not_integrate"] = true;
	}
}