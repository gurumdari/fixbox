var alertDiv = document.querySelector("body > ul > li > div:first-child");
var i18n = $dataset$.i18n;

var loginButton = document.loginForm.querySelector("form > ul > li > div > input + button");

function callLogin() {
	var alertMessage = null;

	var params = {
		user_id:  document.loginForm.user_id.value.trim(),
		password: document.loginForm.password.value
	};

	if (params.user_id == "") {
		alertMessage = i18n.alert.input_user_id;
		document.loginForm.user_id.select();
	} else if (params.password == "") {
		alertMessage = i18n.alert.input_password;
		document.loginForm.password.focus();
	}

	if (alertMessage) {
		alertDiv.innerHTML = alertMessage;
	} else {
		$controller$.loading.show();

		$jnode$.ajax.service({
			"url":      "/ajax/fixbox/login.json",
			"method":   "POST",
			"datatype": "json",
			"headers": {
				"Content-Type": "application/json",
				"Accept":       "application/json"
			},
			"params":  params,
			"success": function(response) {
				document.location.reload();
			},
			"error": function(error) {
				$jnode$.ajax.alertError(error, [
					{"code":"401", "message":"-", "callback":function() {
						alertDiv.innerHTML = i18n.alert.wrong_account;

						document.loginForm.user_id.select();
					}}
				]);

				$controller$.loading.hide();
			}
		});
	}
}

document.loginForm.user_id.addEventListener("keydown", function(event) {
	var keyCode = event.keyCode || event.which;

	if(keyCode == 13) {
		event.preventDefault();

		if (document.loginForm.user_id.value.trim() == "") {
			alertDiv.innerHTML = i18n.alert.input_user_id;
			document.loginForm.user_id.select();
		} else {
			alertDiv.innerHTML = "";
			document.loginForm.password.focus();
		}
	}
}, false);

document.loginForm.password.addEventListener("keydown", function(event) {
	var keyCode = event.keyCode || event.which;

	if(keyCode == 13) {
		event.preventDefault();
		callLogin();
	}
}, false);

document.loginForm.password.addEventListener("keyup", function(event) {
	if (this.value)  loginButton.setAttribute("class", "login");
	else             loginButton.removeAttribute("class");
}, false);

loginButton.addEventListener("click", function(event) {
	callLogin();
}, false);

document.loginForm.user_id.focus();