$content$.settings.account = {
	service: function() {
		var articleNotificationNode = document.querySelector("body > section > article > div.article > div.notification");
		var popupNotificationNode   = document.querySelector("aside.popup > ul > li > div > article > div.popup > article > div.tabarticle > div.notification");
		var passwordRevealButton    = document.accountForm.querySelector("form > table.form > tbody > tr > td.password > ul > li:last-child > button");

		var articleNotSetDatabaseNode = articleNotificationNode.querySelector("div.notification > div.not_set_database");
		if (articleNotSetDatabaseNode) {
			var popupNotSetDatabaseNode = document.createElement("div");
			popupNotSetDatabaseNode.setAttribute("class", "not_set_database");
			popupNotSetDatabaseNode.appendChild(document.createTextNode(i18n.notice.not_set_database))
			popupNotificationNode.appendChild(popupNotSetDatabaseNode);
		}

		var articleDbErrorNode = articleNotificationNode.querySelector("div.notification > div.db_error");
		if (articleDbErrorNode) {
			var popupDbErrorNode = document.createElement("div");
			popupDbErrorNode.setAttribute("class", "db_error");
			popupDbErrorNode.innerHTML = articleDbErrorNode.innerHTML;
			popupNotificationNode.appendChild(popupDbErrorNode);
		}

		var popupNotHiddenNodeCount = popupNotificationNode.querySelectorAll("div > div:not(.hidden)").length;
		if (popupNotHiddenNodeCount > 0) {
			popupNotificationNode.setAttribute("class", "notification");
		}

		passwordRevealButton.addEventListener("click", function(event) {
			if (this.getAttribute("class") == "revealed") {
				this.removeAttribute("class");
				document.accountForm.connection__password.setAttribute("type", "password");
			} else {
				this.setAttribute("class", "revealed");
				document.accountForm.connection__password.setAttribute("type", "text");
			}
		}, false);

		function getPDOConf() {
			var options = {
				connection: {
					dsn:      document.accountForm.connection__dsn.value.trim(),
					username: document.accountForm.connection__username.value.trim(),
					password: document.accountForm.connection__password.value
				},
				domains: {
					table_name:  document.accountForm.domains__table_name.value.trim(),
					domain_id:   document.accountForm.domains__domain_id.value.trim(),
					domain_name: document.accountForm.domains__domain_name.value.trim(),
					domain_sort: document.accountForm.domains__domain_sort.value.trim()
				},
				users: {
					table_name: document.accountForm.users__table_name.value.trim(),
					domain_id:  document.accountForm.users__domain_id.value.trim(),
					email:      document.accountForm.users__email.value.trim(),
					password:   document.accountForm.users__password.value
				},
				aliases: {
					table_name:        document.accountForm.aliases__table_name.value.trim(),
					domain_id:         document.accountForm.aliases__domain_id.value.trim(),
					source_email:      document.accountForm.aliases__source_email.value.trim(),
					destination_email: document.accountForm.aliases__destination_email.value.trim()
				}
			};

			if (options.domains.domain_sort == "") {
				delete options.domains.domain_sort;
			}

			return options;
		}

		var currOptions = JSON.stringify(getPDOConf());

		document.querySelector("aside.popup > ul > li > div > article > div.popup > article > div.tabarticle > form > ul.submit > li > button").addEventListener("click", function(event) {
			var alertLi      = this.parentNode.previousElementSibling;
			var alertMessage = null;

			var params = getPDOConf();

			outer:
			for (var session in params) {
				for (var key in params[session]) {
					if (params[session][key] == "") {
						var inputName = session + "__" + key;
						alertMessage = i18n.alert["input_" + inputName];
						document.accountForm[inputName].select();
						break outer;
					}
				}
			}

			if (alertMessage) {
				alertLi.innerHTML = alertMessage;
			} else {
				$controller$.loading.show();

				passwordRevealButton.removeAttribute("class");
				document.accountForm.connection__password.setAttribute("type", "password");

				if (currOptions == JSON.stringify(params)) {
					window.setTimeout(function() {
						$controller$.loading.hide();
					}, 200);
				} else {
					params.domain_count = domainContainer.children.length;

					$jnode$.ajax.service({
						"url":      "/ajax/settings/account.json",
						"method":   "POST",
						"datatype": "json",
						"headers": {
							"Content-Type": "application/json",
							"Accept":       "application/json"
						},
						"params":  params,
						"success": function(response) {
							$dataset$.not_set_database = false;

							if ($dataset$.empty_orderby1 != response.empty_orderby1) {
								$dataset$.empty_orderby1 = response.empty_orderby1;
								setDomainSort(response.empty_orderby1);
							}

							if (params.domain_count == 0) {
								var domainList = response.domain_list;
								for (var i = 0; i < domainList.length; i++) {
									setDomain(domainList[i]);
								}

								if (response.db_error == null) {
									delete $dataset$.db_error;

									if ($dataset$.loaded_pdo) {
										domainAddButton.disabled = false;
									}
								} else {
									$dataset$.db_error = response.db_error;
									domainAddButton.disabled = true;
								}
							}

							var options = {
								reflect:     "/settings/account",
								domain_name: ""
							};

							var selectedDomain = domainContainer.querySelector("div > label > input:checked");

							if (selectedDomain) {
								options.domain_id   = selectedDomain.value;
								options.domain_name = selectedDomain.nextElementSibling.firstChild.nodeValue;

								var selectedRow = document.querySelector("aside.grid > div > table > tbody > tr.selected");
								if (selectedRow) {
									options.email = selectedRow.getAttribute("id");
								}
							}

							$jnode$.requireContent("article", "/domain/mails", options);
							$controller$.popup.close();
						},
						"error": function(error) {
							$jnode$.ajax.alertError(error);

							$controller$.loading.hide();
						}
					});
				}
			}
		}, false);
	}
}