<?php
$fixBox   = new \Gurumdari\FixBox();
$settings = $fixBox->getConfig()["system"];

$whitelist_file = $settings["whitelist_file"];
$blacklist_file = $settings["blacklist_file"];

if ($whitelist_file[0] != "/")  $whitelist_file = $jnode::$TEMPLATE_PATH."/config/".$whitelist_file;
if ($blacklist_file[0] != "/")  $blacklist_file = $jnode::$TEMPLATE_PATH."/config/".$blacklist_file;

$jnode_dataset["whitelist_file_exists"] = file_exists($whitelist_file);
$jnode_dataset["blacklist_file_exists"] = file_exists($blacklist_file);

if ($jnode_dataset["whitelist_file_exists"]) {
	$jnode_dataset["whitelist_file_writable"] = is_writable($whitelist_file);
} else {
	$jnode_dataset["whitelist_file_writable"] = false;
}

if ($jnode_dataset["blacklist_file_exists"]) {
	$jnode_dataset["blacklist_file_writable"] = is_writable($blacklist_file);
} else {
	$jnode_dataset["blacklist_file_writable"] = false;
}

if ($jnode_dataset["whitelist_file_writable"] && $jnode_dataset["blacklist_file_writable"]) {
	$white_black_list = $fixBox->getWhiteBlackListFromSpamassassin();
	$jnode_dataset["whitelist"] = $white_black_list["whitelist"];
	$jnode_dataset["blacklist"] = $white_black_list["blacklist"];
}