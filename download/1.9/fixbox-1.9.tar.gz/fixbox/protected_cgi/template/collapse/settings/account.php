<?php
$fixBox        = new \Gurumdari\FixBox();
$jnode_dataset = $fixBox->getPDOConf();

if (empty($jnode_dataset)) {
	$jnode_dataset = [
		"connection" => [],
		"domains"    => [],
		"users"      => [],
		"aliases"    => []
	];
}