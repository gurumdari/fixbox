$content$.settings.system = {
	service: function() {
		var that = this;
		var curLang = this.dataset.settings.lang;
		var spamassassinNotificationDiv = document.spamassassinForm.previousElementSibling;
		var requiredScoreDiv            = spamassassinNotificationDiv.querySelector("div > div.required_score");
		var scoreFileExistsDiv          = spamassassinNotificationDiv.querySelector("div > div.score_file_exists");
		var scoreFileWritableDiv        = spamassassinNotificationDiv.querySelector("div > div.score_file_writable");
		var whitelistFileExistsDiv      = spamassassinNotificationDiv.querySelector("div > div.whitelist_file_exists");
		var whitelistFileWritableDiv    = spamassassinNotificationDiv.querySelector("div > div.whitelist_file_writable");
		var blacklistFileExistsDiv      = spamassassinNotificationDiv.querySelector("div > div.blacklist_file_exists");
		var blacklistFileWritableDiv    = spamassassinNotificationDiv.querySelector("div > div.blacklist_file_writable");
		var spamassassinOkButton        = document.spamassassinForm.querySelector("form > ul > li > button");

		if (scoreFileWritableDiv) {
			if (this.dataset.score_file_exists) {
				scoreFileExistsDiv.setAttribute("class", "score_file_exists hidden");

				if (this.dataset.score_file_writable)  scoreFileWritableDiv.setAttribute("class", "score_file_writable hidden");
			} else {
				scoreFileWritableDiv.setAttribute("class", "score_file_writable hidden");
			}

			if (this.dataset.whitelist_file_exists) {
				whitelistFileExistsDiv.setAttribute("class", "whitelist_file_exists hidden");

				if (this.dataset.whitelist_file_writable)  whitelistFileWritableDiv.setAttribute("class", "whitelist_file_writable hidden");
			} else {
				whitelistFileWritableDiv.setAttribute("class", "whitelist_file_writable hidden");
			}

			if (this.dataset.blacklist_file_exists) {
				blacklistFileExistsDiv.setAttribute("class", "blacklist_file_exists hidden");

				if (this.dataset.blacklist_file_writable)  blacklistFileWritableDiv.setAttribute("class", "blacklist_file_writable hidden");
			} else {
				blacklistFileWritableDiv.setAttribute("class", "blacklist_file_writable hidden");
			}
		} else {
			spamassassinOkButton.disabled = false;
		}

		document.systemForm.querySelector("form > ul > li > button").addEventListener("click", function(event) {
			$controller$.loading.show();

			params = {
				name:  "system",
				value: [
					document.systemForm.lang.value,
					document.systemForm.theme.value
				]
			};

			if ((curLang == params.value[0]) && ($jnode$.selector.theme == params.value[1])) {
				window.setTimeout(function() {
					$controller$.loading.hide();
				}, 200);
			} else {
				$jnode$.ajax.service({
					"url":      "/ajax/settings/system.json",
					"method":   "POST",
					"datatype": "json",
					"headers": {
						"Content-Type": "application/json",
						"Accept":       "application/json"
					},
					"params":  params,
					"success": function(response) {
						if ($jnode$.selector.theme != params.value[1]) {
							$jnode$.node.setTheme(params.value[1]);
						}

						if (curLang == params.value[0]) {
							$controller$.loading.hide();
						} else {
							var options = {
								reflect:     "/settings/system",
								domain_name: ""
							};

							if (domainContainer.children.length) {
								var selectedDomain  = domainContainer.querySelector("div > label > input:checked");
								options.domain_id   = selectedDomain.value;
								options.domain_name = selectedDomain.nextElementSibling.firstChild.nodeValue;

								var selectedRow = document.querySelector("aside.grid > div > table > tbody > tr.selected");
								if (selectedRow) {
									options.email = selectedRow.getAttribute("id");
								}
							}

							i18n = response;
							$jnode$.device.lang = i18n.lang;
							document.querySelector("html").setAttribute("lang", i18n.lang);
							$jnode$.node.setLabelLang(i18n.lang, that.conf);
							$controller$.prompt.setLabel({ok:i18n.label.ok, cancel:i18n.label.cancel});

							$jnode$.requireContent("article", "/domain/mails", options);
							$controller$.popup.close();
						}
					},
					"error": function(error) {
						$jnode$.ajax.alertError(error);
						$controller$.loading.hide();
					}
				});
			}
		}, false);

		document.rainloopForm.querySelector("form > ul > li > button:first-child").addEventListener("click", function(event) {
			$controller$.loading.show();

			var params = {
				name:  "integrate_rainloop",
				value: document.rainloopForm.integrate_rainloop[0].checked ? "1" : ""
			};

			if ($dataset$.integrate_rainloop == params.value) {
				window.setTimeout(function() {
					$controller$.loading.hide();
				}, 200);
			} else {
				var domainNameSpan = document.querySelector("body > nav > div > label > input:checked + span");

				if (domainNameSpan) {
					params.domain_name = domainNameSpan.firstChild.nodeValue;
				}

				$jnode$.ajax.service({
					"url":      "/ajax/settings/system.json",
					"method":   "POST",
					"datatype": "json",
					"headers": {
						"Content-Type": "application/json",
						"Accept":       "application/json"
					},
					"params":  params,
					"success": function(response) {
						$dataset$.integrate_rainloop = params.value;

						if (response && response.not_integrate != null) {
							var notIntegrateNode = document.querySelector("body > section > article > div.article > div.notification > div.not_integrate");
							var notificationNode = notIntegrateNode.parentNode;

							if (response.not_integrate) {
								notIntegrateNode.setAttribute("class", "not_integrate");
								notificationNode.setAttribute("class", "notification");
							} else {
								notIntegrateNode.setAttribute("class", "not_integrate hidden");

								var notHiddenNodeCount = notificationNode.querySelectorAll("div > div:not(.hidden)").length;

								if (notHiddenNodeCount == 0) {
									notificationNode.setAttribute("class", "notification hidden");
								}
							}

							$content$.domain.mails.resize();
						}

						$controller$.loading.hide();
					},
					"error": function(error) {
						$jnode$.ajax.alertError(error);
						$controller$.loading.hide();
					}
				});
			}
		}, false);

		document.rainloopForm.querySelector("form > ul > li > button:last-child").addEventListener("click", function(event) {
			$controller$.loading.show();

			$jnode$.ajax.service({
				"url":      "/ajax/settings/rainloop/installer.json",
				"method":   "POST",
				"datatype": "json",
				"headers": {
					"Content-Type": "application/json",
					"Accept":       "application/json"
				},
				"params": {
					command: "install"
				},
				"success": function(response) {
					if (response.webmail_domains) {
						document.rainloopForm.setAttribute("class", "integrate");
					} else {
						$controller$.prompt.alert(response.message);
					}

					$controller$.loading.hide();
				},
				"error": function(error) {
					$jnode$.ajax.alertError(error);
					$controller$.loading.hide();
				}
			});
		}, false);

		document.spamassassinForm.spamassassin_score.addEventListener("input", function(event) {
			this.parentNode.nextElementSibling.innerHTML = parseFloat(this.value).toFixed(1);
		}, false);

		// IE는 input event가 안 먹기 때문에 change event를 추가로 구현
		document.spamassassinForm.spamassassin_score.addEventListener("change", function(event) {
			this.parentNode.nextElementSibling.innerHTML = parseFloat(this.value).toFixed(1);
		}, false);

		document.spamassassinForm.querySelector("form > ul > li > button").addEventListener("click", function(event) {
			var alertMessage = null;
			var alertLi      = this.parentNode.previousElementSibling;
			var ajaxUrl      = "/ajax/settings/system.json";
			var formClass    = document.spamassassinForm.getAttribute("class");
			var params       = {};

			if (formClass == "antispam_settings_file") {
				params = {
					name:  formClass,
					value: [
						document.spamassassinForm.score_file.value.trim(),
						document.spamassassinForm.whitelist_file.value.trim(),
						document.spamassassinForm.blacklist_file.value.trim()
					]
				};

				if (params.value[0] == "") {
					alertMessage = i18n.alert.input_score_file;
					document.spamassassinForm.score_file.select();
				} else if (("/" + params.value[0]).search(/\/\.[^\.\/]/) > -1) {
					alertMessage = i18n.alert.invalid_directory_name;
					document.spamassassinForm.score_file.select();
				} else if (params.value[1] == "") {
					alertMessage = i18n.alert.input_whitelist_file;
					document.spamassassinForm.whitelist_file.select();
				} else if (("/" + params.value[1]).search(/\/\.[^\.\/]/) > -1) {
					alertMessage = i18n.alert.invalid_directory_name;
					document.spamassassinForm.whitelist_file.select();
				} else if (params.value[2] == "") {
					alertMessage = i18n.alert.input_blacklist_file;
					document.spamassassinForm.blacklist_file.select();
				} else if (("/" + params.value[2]).search(/\/\.[^\.\/]/) > -1) {
					alertMessage = i18n.alert.invalid_directory_name;
					document.spamassassinForm.blacklist_file.select();
				}
			} else {
				ajaxUrl = "/ajax/settings/spamassassin/score.json";
				params.spamassassin_score = parseFloat(document.spamassassinForm.spamassassin_score.value).toFixed(1);
			}

			if (alertMessage) {
				alertLi.innerHTML = alertMessage;
			} else {
				$controller$.loading.show();

				$jnode$.ajax.service({
					"url":      ajaxUrl,
					"method":   "POST",
					"datatype": "json",
					"headers": {
						"Content-Type": "application/json",
						"Accept":       "application/json"
					},
					"params": params,
					"success": function(response) {
						if (formClass == "antispam_settings_file") {
							alertLi.innerHTML = "";

							if (response.score_file_writable && response.whitelist_file_writable && response.blacklist_file_writable) {
								document.spamassassinForm.setAttribute("class", "spamassassin_score");

								requiredScoreDiv.setAttribute("class", "required_score");
								spamassassinNotificationDiv.removeChild(spamassassinNotificationDiv.querySelector("div > div.relative_path"));
								spamassassinNotificationDiv.removeChild(scoreFileExistsDiv);
								spamassassinNotificationDiv.removeChild(scoreFileWritableDiv);
								spamassassinNotificationDiv.removeChild(whitelistFileExistsDiv);
								spamassassinNotificationDiv.removeChild(whitelistFileWritableDiv);
								spamassassinNotificationDiv.removeChild(blacklistFileExistsDiv);
								spamassassinNotificationDiv.removeChild(blacklistFileWritableDiv);
							} else {
								if (response.score_file_exists) {
									whitelistFileExistsDiv.setAttribute("class", "score_file_exists hidden");

									if (response.score_file_writable)  scoreFileWritableDiv.setAttribute("class", "score_file_writable hidden");
									else                               scoreFileWritableDiv.setAttribute("class", "score_file_writable");
								} else {
									scoreFileExistsDiv.setAttribute("class", "score_file_exists");
									scoreFileWritableDiv.setAttribute("class", "score_file_writable hidden");
								}

								if (response.whitelist_file_exists) {
									whitelistFileExistsDiv.setAttribute("class", "whitelist_file_exists hidden");

									if (response.whitelist_file_writable)  whitelistFileWritableDiv.setAttribute("class", "whitelist_file_writable hidden");
									else                                   whitelistFileWritableDiv.setAttribute("class", "whitelist_file_writable");
								} else {
									whitelistFileExistsDiv.setAttribute("class", "whitelist_file_exists");
									whitelistFileWritableDiv.setAttribute("class", "whitelist_file_writable hidden");
								}

								if (response.blacklist_file_exists) {
									blacklistFileExistsDiv.setAttribute("class", "blacklist_file_exists hidden");

									if (response.blacklist_file_writable)  blacklistFileWritableDiv.setAttribute("class", "blacklist_file_writable hidden");
									else                                   blacklistFileWritableDiv.setAttribute("class", "blacklist_file_writable");
								} else {
									blacklistFileExistsDiv.setAttribute("class", "blacklist_file_exists");
									blacklistFileWritableDiv.setAttribute("class", "blacklist_file_writable hidden");
								}
							}
						}

						$controller$.loading.hide();
					},
					"error": function(error) {
						$jnode$.ajax.alertError(error);
						$controller$.loading.hide();
					}
				});
			}
		}, false);
	}
}