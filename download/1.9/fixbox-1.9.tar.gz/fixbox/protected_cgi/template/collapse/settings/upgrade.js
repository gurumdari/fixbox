$content$.settings.upgrade = {
	service: function() {
		document.querySelector("aside.winup article > div.winup > form > ul > li:last-child > button").addEventListener("click", function(event) {
			var formData = new FormData(document.upgradeForm);

			if (formData.get("xuz").name.search(/\.xuz$/i) < 0) {
				this.parentNode.previousElementSibling.innerHTML = i18n.alert.select_xuz_file;
			} else {
				$controller$.loading.show();
				this.parentNode.previousElementSibling.innerHTML = "";

				$jnode$.ajax.service({
					"url":      "/ajax/settings/upgrade.json",
					"method":   "POST",
					"datatype": "json",
					"headers":  {
						"Accept": "application/json"
					},
					"params":  formData,
					"success": function(response) {
						var options = {
							reflect:     "/settings/about",
							domain_name: ""
						};

						var selectedDomain = domainContainer.querySelector("div > label > input:checked");

						if (selectedDomain) {
							options.domain_id   = selectedDomain.value;
							options.domain_name = selectedDomain.nextElementSibling.firstChild.nodeValue;

							var selectedRow = document.querySelector("aside.grid > div > table > tbody > tr.selected");
							if (selectedRow) {
								options.email = selectedRow.getAttribute("id");
							}
						}

						var versionName = response.version_name;
						if (versionName) {
							$jnode$.cachePreventVersion = versionName;
						}
						
						$jnode$.requireContent("article", "/domain/mails", options);
						$controller$.winup.close();
						$controller$.popup.close();
					},
					"error": function(error) {
						$jnode$.ajax.alertError(error);
						$controller$.loading.hide();
					}
				});
			}
		}, false);
	}
};