$content$.settings.about = {
	service: function() {
		var alertMessage = null;

		if (!this.dataset.config_writable) {
			alertMessage = i18n.notice.invalid_config_writable;
		} else if (!this.dataset.loaded_zip) {
			alertMessage = i18n.notice.require_zip;
		}

		document.querySelector("aside.popup > ul > li > div > article > div.popup > article > div.tabarticle > fieldset > div:last-child > a").addEventListener("click", function(event) {
			if (alertMessage) {
				$controller$.prompt.alert(alertMessage, null, true);
			} else {
				$jnode$.requireContent("winup", "/settings/upgrade", {
					icon:     true,
					title:    i18n.label.upgrade_version,
					width:    420,
					height:   114
				});
			}
		}, false);
	}
};