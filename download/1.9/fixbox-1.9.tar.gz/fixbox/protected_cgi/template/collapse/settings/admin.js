$content$.settings.admin = {
	service: function() {
		document.querySelector("aside.popup > ul > li > div > article > div.popup > article > div.tabarticle > form > ul.submit > li > button").addEventListener("click", function(event) {
			var alertLi      = this.parentNode.previousElementSibling;
			var alertMessage = null;

			var params = {
				user_id:      document.adminForm.user_id.value.trim(),
				cur_password: document.adminForm.cur_password.value,
				new_password: document.adminForm.new_password.value
			};

			if (params.cur_password == "") {
				alertMessage = i18n.alert.input_current_password;
				document.adminForm.cur_password.focus();
			} else if (params.user_id == "") {
				alertMessage = i18n.alert.input_new_admin_id;
				document.adminForm.user_id.select();
			} else if (params.new_password == "") {
				alertMessage = i18n.alert.input_new_password;
				document.adminForm.new_password.focus();
			} else if (params.new_password != document.adminForm.confirm_password.value) {
				alertMessage = i18n.alert.different_new_password;
				document.adminForm.confirm_password.focus();
			}

			if (alertMessage) {
				alertLi.innerHTML = alertMessage;
			} else {
				$controller$.loading.show();

				$jnode$.ajax.service({
					"url":      "/ajax/settings/admin.json",
					"method":   "POST",
					"datatype": "json",
					"headers": {
						"Content-Type": "application/json",
						"Accept":       "application/json"
					},
					"params":  params,
					"success": function(response) {
						document.adminForm.cur_password.value = "";
						document.adminForm.new_password.value = "";
						document.adminForm.confirm_password.value = "";
						alertLi.innerHTML = "";

						delete $dataset$.plain_password;

						var popupNotificationNode = document.querySelector("aside.popup > ul > li > div > article > div.popup > article > div.tabarticle > div.notification");
						if (popupNotificationNode) {
							popupNotificationNode.parentNode.removeChild(popupNotificationNode);
						}

						var plainPasswordNode = document.querySelector("body > section > article > div.article > div.notification > div.plain_password");

						if (plainPasswordNode) {
							var notificationNode = plainPasswordNode.parentNode;
							notificationNode.removeChild(plainPasswordNode);

							var notHiddenNodeCount = notificationNode.querySelectorAll("div > div:not(.hidden)").length;

							if (notHiddenNodeCount == 0) {
								notificationNode.setAttribute("class", "notification hidden");
							}

							$content$.domain.mails.resize();
						}

						$controller$.loading.hide();
					},
					"error": function(error) {
						$jnode$.ajax.alertError(error, [
							{"code":"401", "message":"-", "callback":function() {
								alertLi.innerHTML = i18n.alert.wrong_current_password;

								document.adminForm.cur_password.select();
							}}
						]);

						$controller$.loading.hide();
					}
				});
			}

		}, false);
	}
};