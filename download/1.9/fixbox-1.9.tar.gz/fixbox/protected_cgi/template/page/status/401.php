<?php
$fixBox = new \Gurumdari\FixBox();

$jnode_dataset = [
	'i18n'  => $fixBox->getI18n(),
	'theme' => $fixBox->getConfig()['system']['theme']
];