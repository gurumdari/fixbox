<?php
require_once 'autoload.php';

$jnode = new \Gurumdari\Jnode();
$jnode->registMods();

$fixBox = new \Gurumdari\FixBox();
$theme  = $fixBox->getConfig()['system']['theme'];