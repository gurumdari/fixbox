function handleHash(hash, nodeConf) {
	var separatedHashs = hash.split(":");
	var nodeType       = separatedHashs[0].substring(1);

	/*
	var nodeId         = separatedHashs[1];

	if (nodeId) {
		if (nodeId.indexOf("/") != 0)  nodeId = "/" + nodeId;
	} else {
		nodeId = "/index";
	}
	*/

	if (nodeType == "article") {
		if (nodeConf.domain_id) {
			document.querySelector("body > nav > div > label > input[value='" + nodeConf.domain_id + "']").click();
		} else {
			$jnode$.requireContent("article", "/domain/accounts", nodeConf);
		}
	}
}

var historyHandler = {
	handler: handleHash
}