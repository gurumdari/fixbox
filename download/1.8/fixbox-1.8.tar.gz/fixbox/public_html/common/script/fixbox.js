var sectionNode        = document.querySelector("body > section");
var articleNode        = sectionNode.lastElementChild;
var navNode            = sectionNode.previousElementSibling;
var domainContainer    = navNode.firstElementChild;
var settingsButton     = navNode.querySelector("nav > ul > li:first-child > button");
var domainAddButton    = settingsButton.parentNode.nextElementSibling.firstElementChild;
var domainRemoveButton = domainAddButton.nextElementSibling;
var domainSortButton   = domainRemoveButton.nextElementSibling;
var swappingButton     = sectionNode.querySelector("section > header > ul > li:first-child > button");
var mailAddButton      = swappingButton.parentNode.nextElementSibling.nextElementSibling.firstElementChild;
var mailEditButton     = mailAddButton.nextElementSibling;
var mailPasswordButton = mailEditButton.nextElementSibling;
var i18n               = $dataset$.i18n;

function resize(event) {
	var windowWidth  = window.innerWidth;
	var windowHeight = window.innerHeight;

	if (window.innerWidth > 736) {
		navNode.removeAttribute("class");
		swappingButton.setAttribute("class", "folding");
	}

	domainContainer.style.height = (windowHeight - 92) + "px";
	articleNode.style.height = (windowHeight - 108) + "px";
}

window.addEventListener("resize", resize, false);
resize();

if ($dataset$.loaded_pdo && !$dataset$.not_set_database && ($dataset$.db_error == null)) {
	domainAddButton.disabled = false;
}

document.querySelector("body > header > ul > li:last-child > form > button").addEventListener("click", function(event) {
	document.logoutForm.submit();
}, false);

var domainList = $dataset$.domain_list;

domainRemoveButton.disabled = true;

if (domainList == null) {
	domainList = [];
}

function setDomain(domainInfo, focus) {
	var domainLabel = document.createElement("label");
	domainContainer.appendChild(domainLabel);

	var domainInput = document.createElement("input");
	domainInput.setAttribute("name", "domain_id");
	domainInput.setAttribute("type", "radio");
	domainInput.value = domainInfo.domain_id;
	domainLabel.appendChild(domainInput);

	var domainSpan = document.createElement("span");
	domainSpan.appendChild(document.createTextNode(domainInfo.domain_name));
	domainLabel.appendChild(domainSpan);

	domainInput.addEventListener("click", function(event) {
		var domainId   = this.value;
		var domainName = this.nextElementSibling.firstChild.nodeValue;
		domainRemoveButton.disabled = false;

		if (swappingButton.getAttribute("class") == "unfolding")  swappingButton.click();

		$jnode$.requireContent("article", "/domain/mails", {
			domain_id:   domainId,
			domain_name: domainName
		});
	}, false);

	if (focus) {
		domainContainer.scrollTop = domainContainer.scrollHeight;
		domainInput.click();

		if (domainSortButton)  domainSortButton.disabled = (domainContainer.children.length < 2);
	}
}

for (var i = 0; i < domainList.length; i++) {
	setDomain(domainList[i]);
}

if (domainList.length) {
	domainContainer.firstElementChild.firstElementChild.click();
} else {
	$jnode$.requireContent("article", "/domain/mails", {
		domain_name: ""
	});
}

swappingButton.addEventListener("click", function(event) {
	if (this.getAttribute("class") == "unfolding") {
		this.setAttribute("class", "folding");
		navNode.setAttribute("class", "folding");
	} else {
		this.setAttribute("class", "unfolding");
		navNode.setAttribute("class", "unfolding");
	}

	this.blur();
}, false);

settingsButton.addEventListener("click", function(event) {
	if (swappingButton.getAttribute("class") == "unfolding")  swappingButton.click();

	$jnode$.requireContent("popup", "/settings", {
		widthP:   100,
		heightP:  100,
		maxWidth: 800
	});
}, false);


domainAddButton.addEventListener("click", function(event) {
	$jnode$.requireContent("winup", "/domain/add", {
		icon:   true,
		title:  i18n.label.add_domain,
		width:  420,
		height: ($dataset$.integrate_rainloop ? 149 : 118)
	});
}, false);

domainRemoveButton.addEventListener("click", function(event) {
	$controller$.prompt.confirm(i18n.alert.confirm_remove_domain, function(close) {
		$controller$.loading.show();

		var selectedDomain = domainContainer.querySelector("div > label > input:checked");

		$jnode$.ajax.service({
			"url":      "/ajax/domain/remove.json",
			"method":   "POST",
			"datatype": "json",
			"headers": {
				"Content-Type": "application/json",
				"Accept":       "application/json"
			},
			"params": {
				domain_id:   selectedDomain.value,
				domain_name: selectedDomain.nextElementSibling.firstChild.nodeValue
			},
			"success": function(response) {
				// if (swappingButton.getAttribute("class") == "unfolding")  swappingButton.click();

				domainContainer.removeChild(selectedDomain.parentNode);
				domainRemoveButton.disabled = true;

				if (domainSortButton)  domainSortButton.disabled = (domainContainer.children.length < 2);

				mailAddButton.disabled      = true;
				mailEditButton.disabled     = true;
				mailPasswordButton.disabled = true;

				$jnode$.requireContent("article", "/domain/mails", {
					domain_name: ""
				});

				$controller$.loading.hide();
			},
			"error": function(error) {
				$jnode$.ajax.alertError(error);
				$controller$.loading.hide();
			}
		});

		close();
	}, null, 2);
}, false);

mailAddButton.addEventListener("click", function(event) {
	$jnode$.requireContent("winup", "/domain/mail/add", {
		icon:        true,
		title:       i18n.label.add_mail_account,
		width:       420,
		height:      362,
		domain_id:   $content$.domain.mails.conf.domain_id,
		domain_name: $content$.domain.mails.conf.domain_name
	});
}, false);

mailEditButton.addEventListener("click", function(event) {
	var selectedUser = document.querySelector("aside.grid > div > table > tbody > tr.selected > td:first-child");

	$jnode$.requireContent("winup", "/domain/mail/edit", {
		icon:      true,
		title:     i18n.label.edit_mail_account,
		width:     420,
		height:    300,
		domain_id: $content$.domain.mails.conf.domain_id,
		email:     selectedUser.firstChild.nodeValue + "@" + $content$.domain.mails.conf.domain_name
	});
}, false);

mailPasswordButton.addEventListener("click", function(event) {
	var selectedUser = document.querySelector("aside.grid > div > table > tbody > tr.selected > td:first-child");

	$jnode$.requireContent("winup", "/domain/mail/password", {
		icon:      true,
		title:     i18n.label.reset_password,
		width:     420,
		height:    180,
		domain_id: $content$.domain.mails.conf.domain_id,
		email:     selectedUser.firstChild.nodeValue + "@" + $content$.domain.mails.conf.domain_name
	});
}, false);

if ($dataset$.empty_orderby1) {
	domainSortButton = null;
} else {
	var checkedValue = null;
	var shiftableEventHandler = new $module$.tap.ShiftableEventHandler(domainContainer, "div > label", function(prevIndex, currIndex) {
		if (checkedValue)  domainContainer.querySelector("div > label > input[value='" + checkedValue + "']").checked = true;

		if (prevIndex > -1 && currIndex > -1 && prevIndex != currIndex) {
			$controller$.loading.show();

			var domainIds = [];
			var domainInputs = domainContainer.querySelectorAll("div > label > input");
			for (var i = 0; i < domainInputs.length; i++) {
				domainIds.push(parseInt(domainInputs[i].value, 10));
			}

			$jnode$.ajax.service({
				"url":      "/ajax/domain/sort.json",
				"method":   "POST",
				"datatype": "json",
				"headers": {
					"Content-Type": "application/json",
					"Accept":       "application/json"
				},
				"params":   {
					"domain_ids": domainIds
				},
				"success": function(response) {
					$controller$.loading.hide();
				},
				"error": function(error) {
					$jnode$.ajax.alertError(error);
					$controller$.loading.hide();
				}
			});
		}
	}, function() {
		var checkedInput = domainContainer.querySelector("div > label > input:checked");
		if (checkedInput)  checkedValue = checkedInput.value;
		else               checkedValue = null;
	}, {
		/* style: "background-color: #FFA666;",*/
		scrollableNode: domainContainer
	});

	if ($jnode$.device.type == "desktop") {
		domainSortButton.parentNode.removeChild(domainSortButton);
		domainSortButton = null;

		shiftableEventHandler.addShiftableEvent();
	} else if (domainSortButton) {
		domainSortButton.removeAttribute("class");
		domainSortButton.disabled = (domainList.length < 2);

		domainSortButton.addEventListener("click", function(event) {
			if (domainContainer.getAttribute("class") == "shiftable") {
				domainContainer.removeAttribute("class");
				this.removeAttribute("class");
				shiftableEventHandler.removeShiftableEvent();
			} else {
				domainContainer.setAttribute("class", "shiftable");
				this.setAttribute("class", "on");
				shiftableEventHandler.addShiftableEvent();
			}
		}, false);
	}
}