<?php
require_once "autoload.php";

$jnode = new \Gurumdari\Jnode();

$request_uri_only = explode('?', $_SERVER["REQUEST_URI"])[0];

if (__FILE__ == $jnode::$HTML_HOME.$request_uri_only) {
	$jnode->sendError(404);
} else {
	$dataset_id = $_GET["id"];

	if ($dataset_id == null) {
		$jnode->sendError(404);
	} else {
		$dataset_id = urldecode($dataset_id);

		if(!isset($_SESSION))  session_start();
		$dataset = $_SESSION[$dataset_id];

		if ($dataset == null) {
			$jnode->sendError(404);
		} else {
			setcookie("Jnode-Frontend-Id", $dataset_id, time() - 3600, "/");
			unset($_SESSION[$dataset_id]);

			echo "\$jnode\$.dataset=".$dataset.";\$dataset\$=\$jnode\$.dataset;";
		}
	}
}