<?php
require_once "autoload.php";

$jnode = new \Gurumdari\Jnode();
$jnode->registMods();

$request_uri_only = explode('?', $_SERVER["REQUEST_URI"])[0];

if (__FILE__ == $jnode::$HTML_HOME.$request_uri_only) {
	$jnode->sendError(404);
} else {
	$jnode->requireAJAX();
}