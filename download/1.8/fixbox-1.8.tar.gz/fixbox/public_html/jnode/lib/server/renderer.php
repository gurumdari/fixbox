<?php
require_once "autoload.php";

$jnode = new \Gurumdari\Jnode();
$jnode->registMods();
$jnode->checkHTML5();

$request_uri_only = explode('?', $_SERVER["REQUEST_URI"])[0];

if (__FILE__ == $jnode::$HTML_HOME.$request_uri_only) {
	$jnode->sendError(404);
} else {
	$template   = "html";
	// $page_id    = $request_uri_only;
	$page_id    = explode("/$/", $request_uri_only)[0];
	$path_index = strrpos($page_id, "/");
	$ext_index  = strrpos($page_id, ".");

	if (($ext_index === false) || ($path_index > $ext_index)) {
		if (substr($page_id, -1) == "/") {
			$page_id = $page_id."index";
		} else {
			$page_id = $page_id."/index";
		}
	} else {
		$page_id = substr($page_id, 0, $ext_index);
	}

	if (isset($_GET["template"]))  $template = $_GET["template"];

	$jnode->requirePage($page_id, $template);
}