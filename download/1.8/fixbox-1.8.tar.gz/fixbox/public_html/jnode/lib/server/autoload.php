<?php
$domain_dirs = [__DIR__, "..", "..", "..", ".."];
$jnode_files = ["protected_cgi", "lib", "Jnode.Framework.php"];
$jnode_framework_file = join(DIRECTORY_SEPARATOR, array_merge($domain_dirs, $jnode_files));

if (file_exists($jnode_framework_file)) {
	require_once $jnode_framework_file;
} else {
	# If protected_cgi can not be separated from public_html, it is considered to be located in public_html
	array_pop($domain_dirs);
	$jnode_framework_file = join(DIRECTORY_SEPARATOR, array_merge($domain_dirs, $jnode_files));

	if (file_exists($jnode_framework_file)) {
		require_once $jnode_framework_file;
	} else {
		http_response_code(500);
		echo "Jnode framework structure error";
		exit;
	}
}

$request_uri_only = explode('?', $_SERVER["REQUEST_URI"])[0];

if(!isset($_SESSION))  session_start();

if (empty($_SESSION) || empty($_SESSION["user_info"]) || empty($_SESSION["user_info"]["user_id"])) {
	$request_uri = parse_url($request_uri_only, PHP_URL_PATH);
	
	$ignore_uris = [
		"/",
		"/index.html",
		"/jnode/proxy/frontend_dataset.js",
		"/ajax/fixbox/login.json"
	];

	if (array_search($request_uri, $ignore_uris) === false) {
		$jnode = new \Gurumdari\Jnode();
		$jnode->checkHTML5();
		$jnode->registMods();
		$jnode->sendError(401);
	}
} else if (__FILE__ == $_SERVER['DOCUMENT_ROOT'].$request_uri_only) {
	$jnode = new \Gurumdari\Jnode();
	$jnode->checkHTML5();
	$jnode->sendError(404);
}