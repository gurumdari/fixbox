$content$.domain.add = {
	service: function() {
		document.domainForm.querySelector("form > ul.submit > li > button").addEventListener("click", function(event) {
			var alertMessage = null;
			var alertLi      = this.parentNode.previousElementSibling;

			var params = {
				domain_name:        document.domainForm.domain_name.value.trim(),
				integrate_rainloop: false
			};

			if ($dataset$.integrate_rainloop) {
				params.integrate_rainloop = document.domainForm.integrate_rainloop.checked;
			}

			if (params.domain_name == "") {
				alertMessage = i18n.alert.input_domain_name;
				document.domainForm.domain_name.select();
			} else if (params.domain_name.search(/^((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/) < 0) {
				alertMessage = i18n.alert.invalid_domain_name;
				document.domainForm.domain_name.select();
			}

			if (alertMessage) {
				alertLi.innerHTML = alertMessage;
			} else {
				$controller$.loading.show();

				$jnode$.ajax.service({
					"url":      "/ajax/domain/add.json",
					"method":   "POST",
					"datatype": "json",
					"headers": {
						"Content-Type": "application/json",
						"Accept":       "application/json"
					},
					"params": params,
					"success": function(response) {
						params.domain_id = response.domain_id;
						setDomain(params, true);

						$controller$.winup.close();
						$controller$.loading.hide();
					},
					"error": function(error) {
						$jnode$.ajax.alertError(error, [
							{"code":"409", "message":"-", "callback":function() {
								alertLi.innerHTML = i18n.alert.already_domain_name;

								document.domainForm.domain_name.select();
							}}
						]);

						$controller$.loading.hide();
					}
				});
			}
		}, false);

		document.domainForm.domain_name.focus();
	}
};