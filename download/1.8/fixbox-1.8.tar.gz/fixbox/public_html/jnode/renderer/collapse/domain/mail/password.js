$content$.domain.mail.password = {
	service: function() {
		var that = this;

		document.mailForm.querySelector("form > ul.submit > li > button").addEventListener("click", function(event) {
			var alertMessage = null;
			var alertLi      = this.parentNode.previousElementSibling;

			var params = {
				domain_id: that.conf.domain_id,
				email:     that.conf.email,
				password:  document.mailForm.password.value
			};

			if (params.password == "") {
				alertMessage = i18n.alert.input_new_password;
				document.mailForm.password.focus();
			} else if (params.password != document.mailForm.confirm_password.value) {
				alertMessage = i18n.alert.different_password;
				document.mailForm.confirm_new_password.focus();
			}

			if (alertMessage) {
				alertLi.innerHTML = alertMessage;
			} else {
				$controller$.loading.show();
				alertLi.innerHTML = "";

				$jnode$.ajax.service({
					"url":      "/ajax/domain/mail/password.json",
					"method":   "POST",
					"datatype": "json",
					"headers": {
						"Content-Type": "application/json",
						"Accept":       "application/json"
					},
					"params": params,
					"success": function(response) {
						$controller$.winup.close();
						$controller$.loading.hide();
					},
					"error": function(error) {
						$jnode$.ajax.alertError(error);
						$controller$.loading.hide();
					}
				});
			}

		}, false);
	}
};