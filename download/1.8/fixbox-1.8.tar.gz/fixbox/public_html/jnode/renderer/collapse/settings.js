$content$.settings = {
	service: function() {
		var fieldset         = document.querySelector("aside.popup > ul > li > div > article > div.popup > fieldset");
		var fieldsetTitleDiv = fieldset.querySelector("fieldset > div:first-child");

		$jnode$.reflectLinks(function(link, options) {
			if (fieldset.getAttribute("class") == "expand") {
				fieldset.setAttribute("class", "shrink");
			}

			fieldsetTitleDiv.innerHTML = fieldset.querySelector("fieldset > div:last-child > ul > li > label > input[value='" + link + "'] + span").innerHTML;
			$jnode$.requireURI(link, options);
		});

		if (this.conf.tab_id) {
			fieldset.querySelector("fieldset > div:last-child > ul > li > label > input[value='#tabarticle:" + this.conf.tab_id + "']").click();
		} else {
			fieldset.querySelector("fieldset > div:last-child > ul > li:first-child > label > input").click();
		}

		fieldsetTitleDiv.addEventListener("click", function(event) {
			var fieldset = this.parentNode;

			if (fieldset.getAttribute("class") == "expand") {
				fieldset.setAttribute("class", "shrink");
			} else {
				fieldset.setAttribute("class", "expand");
			}
		}, false);
	}
};