$content$.domain.mail.add = {
	service: function() {
		var that = this;

		$jnode$.requireControllers(["dataframe", "winup#dataframe"], {caller:that.conf}, function() {
			$controller$.dataframe.service({
				fixedLayout: true,
				names: [ "Aliases" ],
				height: 178
			});

			document.mailForm.querySelector("form > ul.submit > li > button").addEventListener("click", function(event) {
				var alertMessage = null;
				var alertLi      = this.parentNode.previousElementSibling;

				var params = {
					domain_id: that.conf.domain_id,
					email:     document.mailForm.email.value.trim(),
					password:  document.mailForm.password.value,
					aliases:   []
				};

				var columnValues = $controller$.dataframe.getColumnVector();

				if (columnValues) {
					params.aliases = columnValues[0].map(function(entry) {
						return entry.trim();
					});
				}

				if (params.email == "") {
					alertMessage = i18n.alert.input_mail_account;
					document.mailForm.email.select();
				} else if (params.email.search(/^(([^<>()\[\]\\.,;:\s@*"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))$/) < 0) {
					alertMessage = i18n.alert.invalid_mail_account;
					document.mailForm.email.select();
				} else if (params.password == "") {
					alertMessage = i18n.alert.input_password;
					document.mailForm.password.focus();
				} else if (params.password != document.mailForm.confirm_password.value) {
					alertMessage = i18n.alert.different_password;
					document.mailForm.confirm_password.focus();
				}

				if (alertMessage == null) {
					params.email = params.email + "@" + that.conf.domain_name;

					var emailIndex = params.aliases.indexOf(params.email);

					if (emailIndex > -1) {
						alertMessage = i18n.alert.same_mail_account;
						document.querySelector("aside.dataframe > div:nth-child(2) > div:first-child > table > tbody > tr:nth-child(" + (emailIndex + 1) + ") > td > input[type='text']").select();
					} else {
						for (var i = 0; i < params.aliases.length; i++) {
							if (params.aliases[i] && (params.aliases[i].search(/^(([^<>()\[\]\\.,;:\s@*"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/) < 0)) {
								alertMessage = i18n.alert.invalid_aliases;
								document.querySelector("aside.dataframe > div:nth-child(2) > div:first-child > table > tbody > tr:nth-child(" + (i + 1) + ") > td > input[type='text']").select();
								break;
							}
						}
					}
				}

				if (alertMessage) {
					alertLi.innerHTML = alertMessage;
				} else {
					params.aliases = params.aliases.filter(function(entry) {
						return entry != "";
					});

					var newAliases = params.aliases.filter(function(entry, index, self) {
						return index == self.indexOf(entry);
					}).sort();

					// ie 11 over
					// var newAliases = Array.from(new Set(params.aliases)).sort();

					function addMail(params) {
						$controller$.loading.show();
						$controller$.dataframe.clear();
						$controller$.dataframe.setColumnVector([params.aliases]);

						alertLi.innerHTML = "";

						$jnode$.ajax.service({
							"url":      "/ajax/domain/mail/add.json",
							"method":   "POST",
							"datatype": "json",
							"headers": {
								"Content-Type": "application/json",
								"Accept":       "application/json"
							},
							"params": params,
							"success": function(response) {
								var mailTbody = document.querySelector("aside.grid > div > table > tbody");

								params.aliases = params.aliases.join(", ");
								$content$.domain.mails.appendMailRow(mailTbody, params);
								$controller$.grid.clear("thead");
								$controller$.grid.moveBottom();

								$controller$.winup.close();
								$controller$.loading.hide();
							},
							"error": function(error) {
								$jnode$.ajax.alertError(error, [
									{"code":"409", "message":"-", "callback":function() {
										alertLi.innerHTML = i18n.alert.already_email;

										document.mailForm.email.select();
									}}
								]);

								$controller$.loading.hide();
							}
						});
					}

					if (params.aliases.length == newAliases.length) {
						params.aliases = newAliases;
						addMail(params);
					} else {
						$controller$.prompt.confirm(i18n.alert.duplicate_email_in_aliases, function(close) {
							params.aliases = newAliases;
							addMail(params);
							close();
						}, null, 1);
					}
				}

			}, false);
		});

		document.mailForm.email.focus();
	}
};