$content$.settings.spam = {
	resize: function(event) {
		var windowWidth  = window.innerWidth;
		var windowHeight = window.innerHeight;
		var dataframeHeight = 0;

		if (windowWidth > 736) {
			dataframeHeight = windowHeight - 98;
		} else if (windowWidth > 480) {
			dataframeHeight = windowHeight - 124;
		} else {
			dataframeHeight = (windowHeight - 124) / 2;
		}

		if (dataframeHeight < 72)  dataframeHeight = 72;

		$controller$["dataframe#whitelist"].resizeHeight(dataframeHeight);
		$controller$["dataframe#blacklist"].resizeHeight(dataframeHeight);
	},

	service: function() {
		var that = this;

		if (this.dataset.whitelist_file_writable && this.dataset.blacklist_file_writable) {
			$jnode$.requireControllers(["dataframe#whitelist", "winup#dataframe:whitelist", "dataframe#blacklist", "winup#dataframe:blacklist"], {caller:that.conf}, function() {
				$controller$["dataframe#whitelist"].service({
					fixedLayout: true,
					names: [ "Whitelist" ]
				});

				$controller$["dataframe#blacklist"].service({
					fixedLayout: true,
					names: [ "Blacklist" ]
				});

				if (that.dataset.whitelist) {
					$controller$["dataframe#whitelist"].setColumnVector([that.dataset.whitelist]);
				}

				if (that.dataset.blacklist) {
					$controller$["dataframe#blacklist"].setColumnVector([that.dataset.blacklist]);
				}

				window.addEventListener("resize", that.resize, false);
				that.resize();

				document.querySelector("aside.popup > ul > li > div > article > div.popup > article > div.tabarticle > ul.submit > li > button").addEventListener("click", function(event) {
					var alertMessage = null;
					var alertLi      = this.parentNode.previousElementSibling;

					var params = {
						whitelist: [],
						blacklist: []
					};

					var whiteColumnValues = $controller$["dataframe#whitelist"].getColumnVector();
					var blackColumnValues = $controller$["dataframe#blacklist"].getColumnVector();

					if (whiteColumnValues) {
						params.whitelist = whiteColumnValues[0].map(function(entry) {
							return entry.trim();
						});
					}

					for (var i = 0; i < params.whitelist.length; i++) {
						if (params.whitelist[i] && (params.whitelist[i].search(/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/) < 0)) {
							alertMessage = i18n.alert.invalid_whitelist;
							document.querySelector("aside.dataframe#whitelist > div:nth-child(2) > div:first-child > table > tbody > tr:nth-child(" + (i + 1) + ") > td > input[type='text']").select();
							break;
						}
					}

					if (alertMessage == null) {
						if (blackColumnValues) {
							params.blacklist = blackColumnValues[0].map(function(entry) {
								return entry.trim();
							});
						}

						for (var i = 0; i < params.blacklist.length; i++) {
							if (params.blacklist[i] && (params.blacklist[i].search(/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/) < 0)) {
								alertMessage = i18n.alert.invalid_blacklist;
								document.querySelector("aside.dataframe#blacklist > div:nth-child(2) > div:first-child > table > tbody > tr:nth-child(" + (i + 1) + ") > td > input[type='text']").select();
								break;
							}
						}
					}

					if (alertMessage) {
						alertLi.innerHTML = alertMessage;
					} else {
						params.whitelist = params.whitelist.filter(function(entry) {
							return entry != "";
						});

						params.blacklist = params.blacklist.filter(function(entry) {
							return entry != "";
						});

						var newWhitelist = params.whitelist.filter(function(entry, index, self) {
							return index == self.indexOf(entry);
						}).sort();

						var newBlacklist = params.blacklist.filter(function(entry, index, self) {
							return index == self.indexOf(entry);
						}).sort();

						function addList(params) {
							$controller$.loading.show();

							$controller$["dataframe#whitelist"].clear();
							$controller$["dataframe#whitelist"].setColumnVector([params.whitelist]);

							$controller$["dataframe#blacklist"].clear();
							$controller$["dataframe#blacklist"].setColumnVector([params.blacklist]);

							alertLi.innerHTML = "";

							$jnode$.ajax.service({
								"url":      "/ajax/settings/spamassassin/spam.json",
								"method":   "POST",
								"datatype": "json",
								"headers": {
									"Content-Type": "application/json",
									"Accept":       "application/json"
								},
								"params": params,
								"success": function(response) {
									$controller$.winup.close();
									$controller$.loading.hide();
								},
								"error": function(error) {
									$jnode$.ajax.alertError(error);
									$controller$.loading.hide();
								}
							});
						}

						if ((params.whitelist.length == newWhitelist.length) && (params.blacklist.length == newBlacklist.length)) {
							params.whitelist = newWhitelist;
							params.blacklist = newBlacklist;
							addList(params);
						} else {
							$controller$.prompt.confirm(i18n.alert.duplicate_email, function(close) {
								params.whitelist = newWhitelist;
								params.blacklist = newBlacklist;
								addList(params);
								close();
							}, null, 1);
						}
					}
				}, false);
			});
		}
	},

	unload: function() {
		if (this.dataset.whitelist_file_writable && this.dataset.blacklist_file_writable)  window.removeEventListener("resize", this.resize, false);
	}
};