<?php
/*
 * Copyright(C) gurumdari.com ALL RIGHT RESERVED.
 * 
 * Please refer to the following address for details.
 * http://commandbridge.org
 */
namespace Gurumdari;

/**
 * Bridge/PHP enables you to get results from other languages through the Command-line Interface.
 * 
 * Bridge/PHP is supported since PHP 5.3.
 * 
 * @author Jeasu Kim
 */
class CommandBridge {

	/**
	 * Bridge/PHP enables you to get results from other languages through the Command-line Interface.
	 * 
	 * Since the execution result is a character string, it can be solved by parsing from JSON notation string result as value object.
	 * 
	 * Although the $dataset is a value object used in PHP, it is automatically converted into a JSON notation string
	 * and converted into a string that can be used in the Command-line Interface.
	 * Therefore, the argument should be finally parsed from JSON notation string result as value object in the callee language.
	 * 
	 * @param  $commands  Command list.
	 * @param  $dataset   Data set to be converted to argument.
	 * @param  $arg_sep   A delimiter that separates Command and Argument.
	 * @return String result executed through Command-line Interface.
	 */
	public function call($commands, $dataset = null, $arg_sep = null) {
		$result      = "";
		$json_arg    = $this->toJsonArg($dataset);
		if ($json_arg == "\"\"")  $json_arg = null;

		for ($i = 0; $i < count($commands); $i++) {
			if (preg_match("/\s/", $commands[$i]) > 0 || preg_match("/\"/", $commands[$i]) > 0 || preg_match("/\'/", $commands[$i]) > 0) {
				$commands[$i] = "\"".preg_replace("/\\\"/", "\\\"", $commands[$i])."\"";
			}
		}

		if (isset($json_arg)) {
			if (isset($arg_sep))  array_push($commands, $arg_sep);
			array_push($commands, $json_arg);
		}

		array_push($commands, "2>&1");

		$pipe = popen(implode(" ", $commands), "r");

		while(!feof($pipe)) {
			$result .= fread($pipe, 1024);
		}

		$error_code = pclose($pipe);

		if ($error_code > 0)  throw new \Exception(rtrim($result));

		return rtrim($result);
	}

	/**
	 * The $dataset is a value object used in PHP, but it is automatically converted to a JSON notation string and returns a string that can be used in Command-line Interface.
	 * 
	 * @param  dataset  Data set to be converted to argument.
	 * @return A string that is escaped to be available in the Command-line Interface after converting the dataset to a JSON notation string.
	 */
	public function toJsonArg($dataset) {
		if (is_null($dataset))  return null;

		$json_arg = null;
		if (gettype($dataset) == "string")  $json_arg = $dataset;
		else                                $json_arg = json_encode($dataset);

		$json_arg = preg_replace("/\\\\\\\\([^n|r|t|'|\"|\\\\])?/m", "\u005c$1", $json_arg);  # replace \ [w/o escape prefix] ==> \u005c
		$json_arg = preg_replace("/\\\\\\\"/m", "\\\\\\\"", $json_arg);  # replace \" ==> \\"
		$json_arg = preg_replace("/\\\"/m", "\\\"", $json_arg);          # replace " ==> \"
		$json_arg = preg_replace("/&/m", "\u0026", $json_arg);    # for unix shell & dos command
		$json_arg = preg_replace("/!/m", "\u0021", $json_arg);    # for unix shell
		$json_arg = preg_replace("/`/m", "\u0060", $json_arg);    # for unix shell
		$json_arg = preg_replace("/[$]/m", "\u0024", $json_arg);  # for unix shell
		$json_arg = preg_replace("/</m", "\u003c", $json_arg);    # for dos command
		$json_arg = preg_replace("/>/m", "\u003e", $json_arg);    # for dos command
		$json_arg = preg_replace("/\|/m", "\u007c", $json_arg);   # for dos command
		return "\"".$json_arg."\"";
	}
}