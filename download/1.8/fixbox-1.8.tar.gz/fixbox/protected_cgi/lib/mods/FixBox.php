<?php
/*
 * Copyright(C) gurumdari.com ALL RIGHT RESERVED.
 *
 * Please refer to the following address for details.
 * http://fixbox.gurumdari.com
 */
namespace Gurumdari;

/**
 * The mailbox accounts management system module.
 *
 * @author Jeasu Kim
 */
class FixBox {
	private static $PDO = null;

	function __construct() {
		$pdo_file = Jnode::$TEMPLATE_PATH."/config/mailbox_pdo.json";

		if (file_exists($pdo_file)) {
			$json_string = file_get_contents($pdo_file);
			$this::$PDO = json_decode($json_string, true);
		}
	}

	public function getI18n() {
		$lang = $this->getConfig()["system"]["lang"];

		if ($lang == "auto")  $lang = substr($_SERVER['HTTP_ACCEPT_LANGUAGE'], 0, 2);

		$lang_file = Jnode::$TEMPLATE_PATH."/config/i18n/lang_".$lang.".ini";

		if (!file_exists($lang_file)){
			$lang = "en";
			$lang_file = Jnode::$TEMPLATE_PATH."/config/i18n/lang_en.ini";
		}

		$i18n = parse_ini_file($lang_file, true);
		$i18n["lang"] = $lang;

		return $i18n;
	}

	public function getConfig() {
		return parse_ini_file(Jnode::$TEMPLATE_PATH."/config/fixbox.ini", true);
	}

	public function setConfig($updated_config) {
		$sections = array_map(function($section, $updated_contents) {
			$contents = array_map(function($key, $value) {
				if (empty($value)) {
					$value = "Off";
				} else if (($key != "admin_id") && ($value == "1")) {
					$value = "On";
				} else if (array_search($key, ["imap_port", "smtp_port"]) === false) {
					$value = "\"".addslashes($value)."\"";
				}

				return "$key = $value";
			}, array_keys($updated_contents), array_values($updated_contents));

			return "[$section]\n".implode("\n", $contents);
		}, array_keys($updated_config), array_values($updated_config));

		file_put_contents(Jnode::$TEMPLATE_PATH."/config/fixbox.ini", implode("\n\n", $sections));
	}

	public function getPDOConf(string $type = null) {
		if (isset($type))  return $this::$PDO[$type];
		else               return $this::$PDO;
	}

	public function setPDOConf(array $pdo_conf) {
		file_put_contents(Jnode::$TEMPLATE_PATH."/config/mailbox_pdo.json", json_encode($pdo_conf, JSON_PRETTY_PRINT));
		$this::$PDO = $pdo_conf;
	}

	public function deleteFile($file) {
		if (is_dir($file)) {
			$child_files = array_diff(scandir($file), array('.','..'));

			foreach ($child_files as $child_file) {
				$this->deleteFile("$file/$child_file");
			}

			return rmdir($file);
		} else {
			return unlink($file);
		}
	}

	public function moveFile($source_file, $target_file) {
		if (is_dir($source_file)) {
			if (!file_exists($target_file))  mkdir($target_file, 0775);

			$child_files = array_diff(scandir($source_file), array('.','..'));

			foreach ($child_files as $child_file) {
				$this->moveFile("$source_file/$child_file", "$target_file/$child_file");
			}
		} else {
			rename($source_file, $target_file);
		}
	}

	/* ****************************** */
	/* Rainloop : Webmail client      */
	/* ****************************** */

	public function setDomainAtRainloop($domain) {
		$mua_config = $this->getConfig()["mua"];

		$rainloop_domain = [
			"imap_host"        => $mua_config["imap_subdomain"].".".$domain,
			"imap_port"        => intval($mua_config["imap_port"]),
			"imap_secure"      => $mua_config["imap_secure"],
			"imap_short_login" => false,
			"sieve_use"        => false,
			"sieve_allow_raw"  => false,
			"sieve_host"       => "" ,
			"sieve_port"       => 4190,
			"sieve_secure"     => "None",
			"smtp_host"        => $mua_config["smtp_subdomain"].".".$domain,
			"smtp_port"        => intval($mua_config["smtp_port"]),
			"smtp_secure"      => $mua_config["smtp_secure"],
			"smtp_short_login" => false,
			"smtp_auth"        => true,
			"smtp_php_mail"    => false,
			"white_list"       => ""
		];

		$contents = array_map(function($key, $value) {
			if (gettype($value) == "boolean") {
				if ($value)  $value = "On";
				else         $value = "Off";
			} else if (gettype($value) == "string") {
				$value = "\"".addslashes($value)."\"";
			}

			return "$key = $value";
		}, array_keys($rainloop_domain), array_values($rainloop_domain));

		file_put_contents(Jnode::$HTML_HOME."/data/_data_/_default_/domains/".$domain.".ini", implode("\n", $contents));
	}

	/* ****************************** */
	/* Spamassassin : Spam filler     */
	/* ****************************** */

	public function getScoreFromSpamassassin() {
		$settings = $this->getConfig()["system"];
		$score_file = $settings["score_file"];

		if ($score_file[0] != "/")  $score_file = Jnode::$TEMPLATE_PATH."/config/".$score_file;
		$contents = file_get_contents($score_file);

		$match_count = preg_match_all("/^\s*(?!#)required_score\s+(\d?\d\.\d)\s*$/im", $contents, $matches, PREG_OFFSET_CAPTURE);
		if ($match_count == 0)  return "0.0";
		else                    return trim($matches[1][0][0]);
	}

	public function setScoreAtSpamassassin($spamassassin_score) {
		$required_score = "required_score ".$spamassassin_score;

		$settings = $this->getConfig()["system"];
		$score_file = $settings["score_file"];

		if ($score_file[0] != "/")  $score_file = Jnode::$TEMPLATE_PATH."/config/".$score_file;

		file_put_contents($score_file, $required_score);
	}

	private function getListWithRegex($key, $list_file) {
		if ($list_file[0] != "/")  $list_file = Jnode::$TEMPLATE_PATH."/config/".$list_file;
		$contents = file_get_contents($list_file);

		$match_count = preg_match_all("/^\s*(?!#)$key\s+(.+)$/im", $contents, $matches, PREG_OFFSET_CAPTURE);
		$list = [];

		for ($i = 0; $i < $match_count; $i++) {
			$list = array_merge($list, preg_split("/[\s,]+/", trim($matches[1][$i][0])));
		}

		return $list;
	}

	public function getWhiteBlackListFromSpamassassin() {
		$settings = $this->getConfig()["system"];

		$whitelist = $this->getListWithRegex("whitelist_from", $settings["whitelist_file"]);
		$blacklist = $this->getListWithRegex("blacklist_from", $settings["blacklist_file"]);

		return [
			"whitelist" => $whitelist,
			"blacklist" => $blacklist
		];
	}

	public function setWhiteBlackListAtSpamassassin($whitelist, $blacklist) {
		$whitelist_from = "";
		$blacklist_from = "";

		if (count($whitelist) > 0)  $whitelist_from = "whitelist_from ".implode(" ", $whitelist);
		if (count($blacklist) > 0)  $blacklist_from = "blacklist_from ".implode(" ", $blacklist);

		$settings = $this->getConfig()["system"];
		$whitelist_file = $settings["whitelist_file"];
		$blacklist_file = $settings["blacklist_file"];

		if ($whitelist_file[0] != "/")  $whitelist_file = Jnode::$TEMPLATE_PATH."/config/".$whitelist_file;
		if ($blacklist_file[0] != "/")  $blacklist_file = Jnode::$TEMPLATE_PATH."/config/".$blacklist_file;

		file_put_contents($whitelist_file, $whitelist_from);
		file_put_contents($blacklist_file, $blacklist_from);
	}

	/* ****************************** */
	/* Virtual mailbox                */
	/* ****************************** */

	public function selectColumn($conn = null, string $query, array $params = null) {
		if ($conn == null)  $conn = $this->getConnection();

		$stmt = $conn->prepare($query);
		$stmt->execute($params);

		return $stmt->fetchColumn();
	}

	public function selectColumnList($conn = null, string $query, array $params = null) {
		if ($conn == null)  $conn = $this->getConnection();

		$stmt = $conn->prepare($query);
		$stmt->execute($params);

		return $stmt->fetchAll(\PDO::FETCH_COLUMN, 0);
	}

	public function selectRow($conn = null, string $query, array $params = null) {
		if ($conn == null)  $conn = $this->getConnection();

		$stmt = $conn->prepare($query);
		$stmt->execute($params);

		return $stmt->fetch(\PDO::FETCH_ASSOC);
	}

	public function selectRowList($conn = null, string $query, array $params = null) {
		if ($conn == null)  $conn = $this->getConnection();

		$stmt = $conn->prepare($query);
		$stmt->execute($params);

		return $stmt->fetchAll(\PDO::FETCH_ASSOC);
	}

	public function executeSQL($conn = null, string $query, array $params = null) {
		if ($conn == null)  $conn = $this->getConnection();

		$stmt = $conn->prepare($query);
		$stmt->execute($params);
	}

	public function insertTableDomain(string $insert_query, string $id_query, string $sort_query = null, array $params) {
		$conn = $this->getConnection();
		$domain_sort = 0;

		if (isset($sort_query)) {
			$domain_sort = $this->selectColumn($conn, $sort_query);

			if ($domain_sort == null)  $params[":domain_sort"] = 0;
			else                       $params[":domain_sort"] = $domain_sort + 1;
		}

		$this->executeSQL($conn, $insert_query, $params);

		return $this->selectColumn($conn, $id_query);
	}

	public function sortTableDomain(string $query, array $domain_ids) {
		$conn = $this->getConnection();
		$conn->beginTransaction();

		try {
			for ($i = 0; $i < count($domain_ids); $i++) {
				$params = [
					":domain_id"   => $domain_ids[$i],
					":domain_sort" => $i
				];

				$this->executeSQL($conn, $query , $params);
			}

			$conn->commit();
		} catch(Exception $e) {
			$conn->rollBack();
			throw $e;
		}
	}

	public function deleteTableDomain(string $alias_query, string $user_query, string $domain_query, string $sort_query = null, array $params) {
		$conn = $this->getConnection();
		$conn->beginTransaction();

		try {
			if (isset($sort_query)) {
				$this->executeSQL($conn, $sort_query, $params);
			}

			$this->executeSQL($conn, $alias_query , $params);
			$this->executeSQL($conn, $user_query  , $params);
			$this->executeSQL($conn, $domain_query, $params);

			$conn->commit();
		} catch(Exception $e) {
			$conn->rollBack();
			throw $e;
		}
	}

	public function insertTableUser(string $users_query, string $aliases_query, array $params, array $aliases) {
		$conn = $this->getConnection();
		$conn->beginTransaction();

		try {
			$this->executeSQL($conn, $users_query, $params);

			$aliases_params = [
				":domain_id"    => $params[":domain_id"],
				":source_email" => $params[":email"]
			];

			for ($i = 0; $i < count($aliases); $i++) {
				$aliases_params[":destination_email"] = $aliases[$i];
				$this->executeSQL($conn, $aliases_query, $aliases_params);
			}

			$conn->commit();
		} catch(Exception $e) {
			$conn->rollBack();
			throw $e;
		}
	}

	public function deleteTableUser(string $alias_query, string $user_query, array $params) {
		$conn = $this->getConnection();
		$conn->beginTransaction();

		try {
			$this->executeSQL($conn, $alias_query, $params);
			$this->executeSQL($conn, $user_query, $params);

			$conn->commit();
		} catch(Exception $e) {
			$conn->rollBack();
			throw $e;
		}
	}

	public function updateTableAlias(string $select_query, string $update_query, string $insert_query, string $delete_query, array $params, array $new_destinations) {
		$conn = $this->getConnection();
		$conn->beginTransaction();

		try {
			$old_destinations = $this->selectColumnList($conn, $select_query, $params);

			$old_count = count($old_destinations);
			$new_count = count($new_destinations);
			$min_count = min($old_count, $new_count);

			// delete
			// NOTE: The same name can exist by changing the order, so they should be deleted in reverse order.
			for ($i = $new_count; $i < $old_count; $i++) {
				$params[":old_destination"] = $old_destinations[$i];

				$this->executeSQL($conn, $delete_query, $params);
			}

			// update
			// NOTE: The same name can exist by changing the order, so they should be updated in reverse order.
			for ($i = $min_count - 1; $i >= 0; $i--) {
				$params[":new_destination"] = $new_destinations[$i];
				$params[":old_destination"] = $old_destinations[$i];

				$this->executeSQL($conn, $update_query, $params);
			}

			// insert
			for ($i = $old_count; $i < $new_count; $i++) {
				if (isset($params[":old_destination"]))  unset($params[":old_destination"]);
				$params[":new_destination"] = $new_destinations[$i];

				$this->executeSQL($conn, $insert_query, $params);
			}

			$conn->commit();
		} catch(Exception $e) {
			$conn->rollBack();
			throw $e;
		}
	}

	private function getConnection() {
		$options = $this->getPDOConf("connection");
		$conn = new \PDO($options["dsn"], $options["username"], $options["password"]);
		$conn->setAttribute(\PDO::ATTR_ERRMODE, \PDO::ERRMODE_EXCEPTION);

		return $conn;
	}
}