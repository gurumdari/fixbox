<?php
$fixBox = new \Gurumdari\FixBox();
$a_options = $fixBox->getPDOConf("aliases");

$select_query = <<<"EOT"
SELECT `{$a_options["destination_email"]}`
  FROM `{$a_options["table_name"]}`
 WHERE `{$a_options["domain_id"]}` = :domain_id
   AND `{$a_options["source_email"]}` = :source_email
 ORDER BY `{$a_options["destination_email"]}` ASC
EOT;

$update_query = <<<"EOT"
UPDATE `{$a_options["table_name"]}`
   SET `{$a_options["destination_email"]}` = :new_destination
 WHERE `{$a_options["domain_id"]}` = :domain_id
   AND `{$a_options["source_email"]}` = :source_email
   AND `{$a_options["destination_email"]}` = :old_destination
 ORDER BY `{$a_options["destination_email"]}` ASC
 LIMIT 1
EOT;

$insert_query = <<<"EOT"
INSERT INTO `{$a_options["table_name"]}`
       (`{$a_options["domain_id"]}`, `{$a_options["source_email"]}`, `{$a_options["destination_email"]}`)
VALUES (:domain_id, :source_email, :new_destination)
EOT;

$delete_query = <<<"EOT"
DELETE FROM `{$a_options["table_name"]}`
 WHERE `{$a_options["domain_id"]}` = :domain_id
   AND `{$a_options["source_email"]}` = :source_email
   AND `{$a_options["destination_email"]}` = :old_destination
EOT;

$params = [
	":domain_id"    => $jnode_jparam["domain_id"],
	":source_email" => $jnode_jparam["source_email"]
];

$fixBox->updateTableAlias($select_query, $update_query, $insert_query, $delete_query, $params, $jnode_jparam["new_destination"]);