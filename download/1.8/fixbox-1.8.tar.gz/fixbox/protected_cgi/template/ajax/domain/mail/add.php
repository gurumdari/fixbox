<?php
$fixBox = new \Gurumdari\FixBox();
$options   = $fixBox->getPDOConf();
$u_options = $options["users"];
$a_options = $options["aliases"];

$users_query = <<<"EOT"
INSERT INTO `{$u_options["table_name"]}`
       (`{$u_options["domain_id"]}`, `{$u_options["email"]}`, `{$u_options["password"]}`)
VALUES (:domain_id, :email, ENCRYPT(:password, CONCAT('$6$', SUBSTRING(SHA(RAND()), -16))))
EOT;

$aliases_query = <<<"EOT"
INSERT INTO `{$a_options["table_name"]}`
       (`{$a_options["domain_id"]}`, `{$a_options["source_email"]}`, `{$a_options["destination_email"]}`)
VALUES (:domain_id, :source_email, :destination_email)
EOT;

$params = [
	":domain_id" => $jnode_jparam["domain_id"],
	":email"     => $jnode_jparam["email"],
	":password"  => $jnode_jparam["password"]
];

try {
	$fixBox->insertTableUser($users_query, $aliases_query, $params, $jnode_jparam["aliases"]);
} catch(\Exception $e) {
	$error_message = $e->getMessage();

	if (strrpos($e->getMessage(), "Duplicate") > 0) {
		$jnode->sendError(409);
	} else {
		throw $e;
	}
}