<?php
$fixBox    = new \Gurumdari\FixBox();
$d_options = $fixBox->getPDOConf("domains");

$sort_query = null;

if (isset($d_options["domain_sort"])) {
	$sort_query = <<<"EOT"
SELECT MAX(`{$d_options["domain_sort"]}`) AS max_sort
  FROM `{$d_options["table_name"]}`
EOT;

	$insert_query = <<<"EOT"
INSERT INTO `{$d_options["table_name"]}`
       (`{$d_options["domain_name"]}`, `{$d_options["domain_sort"]}`)
VALUES (:domain_name, :domain_sort)
EOT;
} else {
	$insert_query = <<<"EOT"
INSERT INTO `{$d_options["table_name"]}`
       (`{$d_options["domain_name"]}`)
VALUES (:domain_name)
EOT;
}

$params = [
	":domain_name" => $jnode_jparam["domain_name"]
];

$id_query = <<<"EOT"
SELECT MAX(`{$d_options["domain_id"]}`) AS domain_id
  FROM `{$d_options["table_name"]}`
EOT;

try {
	$domain_id = $fixBox->insertTableDomain($insert_query, $id_query, $sort_query, $params);

	$jnode_dataset = [
		"domain_id" => $domain_id
	];

	if ($jnode_jparam["integrate_rainloop"]) {
		if (!file_exists($jnode::$HTML_HOME."/data/_data_/_default_/domains/".$jnode_jparam["domain_name"].".ini")) {
			$fixBox->setDomainAtRainloop($jnode_jparam["domain_name"]);
		}
	}
} catch(\Exception $e) {
	$error_message = $e->getMessage();

	if (strrpos($e->getMessage(), "Duplicate") > 0) {
		$jnode->sendError(409);
	} else {
		throw $e;
	}
}