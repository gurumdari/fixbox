<?php
$fixBox = new \Gurumdari\FixBox();
$u_options = $fixBox->getPDOConf("users");

$query = <<<"EOT"
UPDATE `{$u_options["table_name"]}`
   SET `{$u_options["password"]}` = ENCRYPT(:password, CONCAT('$6$', SUBSTRING(SHA(RAND()), -16)))
 WHERE `{$u_options["domain_id"]}` = :domain_id
   AND `{$u_options["email"]}` = :email
EOT;

$params = [
	":domain_id" => $jnode_jparam["domain_id"],
	":email"     => $jnode_jparam["email"],
	":password"  => $jnode_jparam["password"]
];

$fixBox->executeSQL(null, $query, $params);