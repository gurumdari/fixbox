<?php
$fixBox         = new \Gurumdari\FixBox();
$security       = $fixBox->getConfig()["security"];
$plain_password = empty($security["admin_updated"]);
$admin_id       = $jnode_jparam["user_id"];
$admin_password = $jnode_jparam["password"];

if (!$plain_password) {
	$admin_id       = md5($security["admin_updated"].$admin_id);
	$admin_password = md5($admin_password.$security["admin_updated"]);
}

if (($admin_id == $security["admin_id"]) && ($admin_password == $security["admin_password"])) {
	if(!isset($_SESSION))  session_start();
	$_SESSION["user_info"] = [
		"user_id" => $jnode_jparam["user_id"]
	];

	if ($plain_password)  $_SESSION["user_info"]["plain_password"] = true;
} else {
	$jnode->sendError(401);
}