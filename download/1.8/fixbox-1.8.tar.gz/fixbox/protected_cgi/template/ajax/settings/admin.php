<?php
$fixBox         = new \Gurumdari\FixBox();
$fixbox_config  = $fixBox->getConfig();
$security       = $fixbox_config["security"];
$plain_password = empty($security["admin_updated"]);
$cur_password   = $jnode_jparam["cur_password"];

if (!$plain_password) {
	$cur_password = md5($jnode_jparam["cur_password"].$security["admin_updated"]);
}

if ($cur_password == $security["admin_password"]) {
	$admin_id      = $jnode_jparam["user_id"];
	$admin_updated = md5(date("Y-m-d\TH:i:s", time()));

	$fixbox_config["security"] = [
		"admin_id"       => md5($admin_updated.$admin_id),
		"admin_password" => md5($jnode_jparam["new_password"].$admin_updated),
		"admin_updated"  => $admin_updated
	];

	$fixBox->setConfig($fixbox_config);

	if(!isset($_SESSION))  session_start();
	$_SESSION["user_info"] = [
		"user_id" => $admin_id
	];

	// if ($plain_password)  $_SESSION["user_info"]["plain_password"] = true;
} else {
	$jnode->sendError(401);
}