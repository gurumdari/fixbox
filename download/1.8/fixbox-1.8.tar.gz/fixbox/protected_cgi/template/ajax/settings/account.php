<?php
$domain_count = $jnode_jparam["domain_count"];
unset($jnode_jparam["domain_count"]);

$fixBox = new \Gurumdari\FixBox();
$fixBox->setPDOConf($jnode_jparam);

$jnode_dataset = [
	"empty_orderby1" => true,
	"domain_list"    => []
];

$d_options = $jnode_jparam["domains"];
$orderby1  = "";

if (isset($d_options["domain_sort"])) {
	$jnode_dataset["empty_orderby1"] = false;
	$orderby1 = "`{$d_options["domain_sort"]}` ASC, ";
}

if (($domain_count == 0) && extension_loaded("pdo_mysql")) {
	$domains_query = <<<"EOT"
SELECT `{$d_options["domain_id"]}`   AS domain_id
 , `{$d_options["domain_name"]}` AS domain_name
FROM `{$d_options["table_name"]}`
ORDER BY $orderby1`{$d_options["domain_id"]}` ASC
EOT;

	try {
		$jnode_dataset["domain_list"] = $fixBox->selectRowList(null, $domains_query);
	} catch (\Exception $e) {
		$jnode_dataset["db_error"] = $e->getMessage();

		error_log("FixBox Notice: ".$jnode_dataset["db_error"]);
	}
}