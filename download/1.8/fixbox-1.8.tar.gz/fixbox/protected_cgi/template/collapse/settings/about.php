<?php
$fixBox = new \Gurumdari\FixBox();

$upload_dir = $jnode::$TEMPLATE_PATH."/config/xuz";

if (file_exists($upload_dir)) {
	$upgrade_php = $upload_dir."/patch/upgrade.php";
	if (file_exists($upgrade_php))  rename($upgrade_php, $jnode::$TEMPLATE_PATH."/ajax/settings/upgrade.php");

	$fixBox->deleteFile($upload_dir);
}

$jnode_dataset = [
	"cur_version"     => $fixBox->getConfig()["system"]["version"],
	"config_writable" => is_writable($jnode::$TEMPLATE_PATH."/config"),
	"loaded_zip"      => extension_loaded("Zip")
];