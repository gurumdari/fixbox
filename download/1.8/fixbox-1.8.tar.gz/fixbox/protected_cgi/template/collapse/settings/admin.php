<?php
$jnode_dataset = [
	"user_id" => $_SESSION["user_info"]["user_id"]
];