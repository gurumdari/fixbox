<?php
$fixBox   = new \Gurumdari\FixBox();
$settings = $fixBox->getConfig()["system"];

$required_modules = [];
if (!extension_loaded("curl"))  array_push($required_modules, "curl");
if (!extension_loaded("xml") )  array_push($required_modules, "xml");

$lang_files = array_diff(scandir($jnode::$TEMPLATE_PATH."/config/i18n"), array('..', '.'));
$langs = [];

$lang_display_name = [
	"aa" => "Afar (aa)",
	"ab" => "Abkhazian (ab)",
	"ae" => "Avestan (ae)",
	"af" => "Afrikaans (af)",
	"ak" => "Akan (ak)",
	"am" => "Amharic (am), አማርኛ",
	"an" => "Aragonese (an)",
	"ar" => "Arabic (ar), العربية",
	"as" => "Assamese (as), অসমীয়া",
	"av" => "Avaric (av)",
	"ay" => "Aymara (ay)",
	"az" => "Azerbaijani (az), azərbaycan dili",
	"ba" => "Bashkir (ba)",
	"be" => "Belarusian (be), беларуская",
	"bg" => "Bulgarian (bg), български",
	"bh" => "Bihari (bh)",
	"bi" => "Bislama (bi)",
	"bm" => "Bambara (bm), bamanakan",
	"bn" => "Bengali (bn), বাংলা",
	"bo" => "Tibetan (bo), བོད་སྐད་",
	"br" => "Breton (br), brezhoneg",
	"bs" => "Bosnian (bs), bosanski",
	"ca" => "Catalan (ca), català",
	"ce" => "Chechen (ce), нохчийн",
	"ch" => "Chamorro (ch)",
	"co" => "Corsican (co)",
	"cr" => "Cree (cr)",
	"cs" => "Czech (cs), čeština",
	"cu" => "Church Slavic (cu)",
	"cv" => "Chuvash (cv)",
	"cy" => "Welsh (cy), Cymraeg",
	"da" => "Danish (da), dansk",
	"de" => "German (de), Deutsch",
	"dv" => "Divehi (dv)",
	"dz" => "Dzongkha (dz), རྫོང་ཁ",
	"ee" => "Ewe (ee), Eʋegbe",
	"el" => "Greek (el), Ελληνικά",
	"en" => "English (en)",
	"eo" => "Esperanto (eo)",
	"es" => "Spanish (es), español",
	"et" => "Estonian (et), eesti",
	"eu" => "Basque (eu), euskara",
	"fa" => "Persian (fa), فارسی",
	"ff" => "Fulah (ff), Pulaar",
	"fi" => "Finnish (fi), suomi",
	"fj" => "Fijian (fj)",
	"fo" => "Faroese (fo), føroyskt",
	"fr" => "French (fr), français",
	"fy" => "Western Frisian (fy), West-Frysk",
	"ga" => "Irish (ga), Gaeilge",
	"gd" => "Scottish Gaelic (gd), Gàidhlig",
	"gl" => "Galician (gl), galego",
	"gn" => "Guarani (gn)",
	"gu" => "Gujarati (gu), ગુજરાતી",
	"gv" => "Manx (gv), Gaelg",
	"ha" => "Hausa (ha)",
	"he" => "Hebrew (he), עברית",
	"hi" => "Hindi (hi), हिन्दी",
	"ho" => "Hiri Motu (ho)",
	"hr" => "Croatian (hr), hrvatski",
	"ht" => "Haitian (ht), Haitian",
	"hu" => "Hungarian (hu), magyar",
	"hy" => "Armenian (hy), հայերեն",
	"hz" => "Herero (hz)",
	"ia" => "Interlingua (ia)",
	"id" => "Indonesian (id), Bahasa Indonesia",
	"ie" => "Interlingue (ie)",
	"ig" => "Igbo (ig)",
	"ii" => "Sichuan Yi (ii), ꆈꌠꉙ",
	"ik" => "Inupiaq (ik)",
	"io" => "Ido (io)",
	"is" => "Icelandic (is), íslenska",
	"it" => "Italian (it), italiano",
	"iu" => "Inuktitut (iu)",
	"ja" => "Japanese (ja), 日本語",
	"jv" => "Javanese (jv)",
	"ka" => "Georgian (ka), ქართული",
	"kg" => "Kongo (kg)",
	"ki" => "Kikuyu (ki), Gikuyu",
	"kj" => "Kwanyama (kj)",
	"kk" => "Kazakh (kk), қазақ тілі",
	"kl" => "Kalaallisut (kl)",
	"km" => "Khmer (km), ខ្មែរ",
	"kn" => "Kannada (kn), ಕನ್ನಡ",
	"ko" => "Korean (ko), 한국어",
	"kr" => "Kanuri (kr)",
	"ks" => "Kashmiri (ks), کٲشُر",
	"ku" => "Kurdish (ku)",
	"kv" => "Komi (kv)",
	"kw" => "Cornish (kw), kernewek",
	"ky" => "Kirghiz (ky), кыргызча",
	"la" => "Latin (la)",
	"lb" => "Luxembourgish (lb), Lëtzebuergesch",
	"lg" => "Ganda (lg), Luganda",
	"li" => "Limburgish (li)",
	"ln" => "Lingala (ln), lingála",
	"lo" => "Lao (lo), ລາວ",
	"lt" => "Lithuanian (lt), lietuvių",
	"lu" => "Luba-Katanga (lu), Tshiluba",
	"lv" => "Latvian (lv), latviešu",
	"mg" => "Malagasy (mg)",
	"mh" => "Marshallese (mh)",
	"mi" => "Maori (mi)",
	"mk" => "Macedonian (mk), македонски",
	"ml" => "Malayalam (ml), മലയാളം",
	"mn" => "Mongolian (mn), монгол",
	"mr" => "Marathi (mr), मराठी",
	"ms" => "Malay (ms), Bahasa Melayu",
	"mt" => "Maltese (mt), Malti",
	"my" => "Burmese (my), ဗမာ",
	"na" => "Nauru (na)",
	"nb" => "Norwegian Bokmal (nb), norsk bokmål",
	"nd" => "North Ndebele (nd), isiNdebele",
	"ne" => "Nepali (ne), नेपाली",
	"ng" => "Ndonga (ng)",
	"nl" => "Dutch (), Nederlands",
	"nn" => "Norwegian Nynorsk (nn), nynorsk",
	"no" => "Norwegian (no), norsk",
	"nr" => "South Ndebele (nr)",
	"nv" => "Navajo (nv)",
	"ny" => "Chichewa (ny), Nyanja",
	"oc" => "Occitan (oc)",
	"oj" => "Ojibwa (oj)",
	"om" => "Oromo (om), Oromoo",
	"or" => "Oriya (or), ଓଡ଼ିଆ",
	"os" => "Ossetian (os), ирон",
	"pa" => "Panjabi (pa), ਪੰਜਾਬੀ",
	"pi" => "Pali (pi)",
	"pl" => "Polish (pl), polski",
	"ps" => "Pashto (ps), پښتو",
	"pt" => "Portuguese (pt), português",
	"qu" => "Quechua (qu), Runasimi",
	"rm" => "Raeto-Romance (rm), rumantsch",
	"rn" => "Kirundi (rn), Ikirundi",
	"ro" => "Romanian (ro), română",
	"ru" => "Russian (ru), русский",
	"rw" => "Kinyarwanda (rw)",
	"sa" => "Sanskrit (sa)",
	"sc" => "Sardinian (sc)",
	"sd" => "Sindhi (sd)",
	"se" => "Northern Sami (se), davvisámegiella",
	"sg" => "Sango (sg), Sängö",
	"si" => "Sinhala (si), සිංහල",
	"sk" => "Slovak (sk), slovenčina",
	"sl" => "Slovenian (sl), slovenščina",
	"sm" => "Samoan (sm)",
	"sn" => "Shona (sn), chiShona",
	"so" => "Somali (so), Soomaali",
	"sq" => "Albanian (sq), shqip",
	"sr" => "Serbian (sr), српски",
	"ss" => "Swati (ss)",
	"st" => "Southern Sotho (st)",
	"su" => "Sundanese (su)",
	"sv" => "Swedish (sv), svenska",
	"sw" => "Swahili (sw), Kiswahili",
	"ta" => "Tamil (ta), தமிழ்",
	"te" => "Telugu (te), తెలుగు",
	"tg" => "Tajik (tg)",
	"th" => "Thai (th), ไทย",
	"ti" => "Tigrinya (ti), ትግርኛ",
	"tk" => "Turkmen (tk)",
	"tl" => "Tagalog (tl)",
	"tn" => "Tswana (tn)",
	"to" => "Tonga (to), lea fakatonga",
	"tr" => "Turkish (tr), Türkçe",
	"ts" => "Tsonga (ts)",
	"tt" => "Tatar (tt)",
	"tw" => "Twi (tw)",
	"ty" => "Tahitian (ty)",
	"ug" => "Uighur (ug), ئۇيغۇرچە",
	"uk" => "Ukrainian (uk), українська",
	"ur" => "Urdu (ur), اردو",
	"uz" => "Uzbek (uz), o‘zbek",
	"ve" => "Venda (ve)",
	"vi" => "Vietnamese (vi), Tiếng Việt",
	"vo" => "Volapuk (vo), Volapük",
	"wa" => "Walloon (wa)",
	"wo" => "Wolof (wo)",
	"xh" => "Xhosa (xh)",
	"yi" => "Yiddish (yi)",
	"yo" => "Yoruba (yo), Èdè Yorùbá",
	"za" => "Zhuang (za)",
	"zh" => "Chinese (zh), 中文",
	"zu" => "Zulu (zu), isiZulu"
];

foreach ($lang_files as $lang_file) {
	$lang_code = substr($lang_file, 5, 2);

	array_push($langs, [
		"code" => $lang_code,
		"name" => $lang_display_name[$lang_code]
	]);
}

$jnode_dataset = [
	"settings"        => $settings,
	"langs"           => $langs,
	"webmail_modules" => $required_modules,
	"webmail_url"     => $_SERVER["REQUEST_SCHEME"]."://".$_SERVER["HTTP_HOST"],
	"public_writable" => is_writable($jnode::$HTML_HOME),
	"webmail_domains" => file_exists($jnode::$HTML_HOME."/data/_data_/_default_/domains"),
	"spamassassin_score"      => "5.0",
	"score_file_writable"     => false,
	"whitelist_file_writable" => false,
	"blacklist_file_writable" => false
];

if (count($required_modules) > 0 || !$jnode_dataset["public_writable"]) {
	$jnode_dataset["install_disabled"] = true;
}

$score_file     = $settings["score_file"];
$whitelist_file = $settings["whitelist_file"];
$blacklist_file = $settings["blacklist_file"];

if ($score_file[0]     != "/")  $score_file     = $jnode::$TEMPLATE_PATH."/config/".$score_file;
if ($whitelist_file[0] != "/")  $whitelist_file = $jnode::$TEMPLATE_PATH."/config/".$whitelist_file;
if ($blacklist_file[0] != "/")  $blacklist_file = $jnode::$TEMPLATE_PATH."/config/".$blacklist_file;

$jnode_dataset["score_file_exists"]     = file_exists($score_file);
$jnode_dataset["whitelist_file_exists"] = file_exists($whitelist_file);
$jnode_dataset["blacklist_file_exists"] = file_exists($blacklist_file);

if ($jnode_dataset["score_file_exists"]) {
	$jnode_dataset["score_file_writable"] = is_writable($score_file);
}

if ($jnode_dataset["whitelist_file_exists"]) {
	$jnode_dataset["whitelist_file_writable"] = is_writable($whitelist_file);
}

if ($jnode_dataset["blacklist_file_exists"]) {
	$jnode_dataset["blacklist_file_writable"] = is_writable($blacklist_file);
}

if ($jnode_dataset["score_file_writable"]) {
	$jnode_dataset["spamassassin_score"] = $fixBox->getScoreFromSpamassassin();

	if ($jnode_dataset["spamassassin_score"] == "0.0") {
		$jnode_dataset["spamassassin_score"] = "5.0";
		$fixBox->setScoreAtSpamassassin("5.0");
	}
}

if (file_exists("/etc/spamassassin/local.cf")) {
	$jnode_dataset["spam_rule_file"] = "/etc/spamassassin/local.cf";
}