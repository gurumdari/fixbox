<?php
unset($_SESSION["user_info"]);

header("Location: ".$_SERVER['HTTP_REFERER']);