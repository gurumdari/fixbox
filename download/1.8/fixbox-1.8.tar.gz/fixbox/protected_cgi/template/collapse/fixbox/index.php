<?php
$fixBox    = new Gurumdari\FixBox();
$d_options = $fixBox->getPDOConf("domains");

// $config_owner    = posix_getpwuid(fileowner($jnode::$TEMPLATE_PATH."/config"))["name"] == "www-data";
// $config_writable = (decoct(fileperms($jnode::$TEMPLATE_PATH."/config/fixbox.ini") & 0777) % 10 % 4) > 1;

$jnode_dataset = [
	"i18n"               => $fixBox->getI18n(),
	"loaded_pdo"         => extension_loaded("pdo_mysql"),
	"not_set_database"   => empty($d_options),
	"empty_orderby1"     => true,
	"config_writable"    => is_writable($jnode::$TEMPLATE_PATH."/config"),
	"integrate_rainloop" => $fixBox->getConfig()["system"]["integrate_rainloop"],
	"domain_list"        => []
];

if (isset($_SESSION["user_info"]["plain_password"]) && $_SESSION["user_info"]["plain_password"]) {
	$jnode_dataset["plain_password"] = true;
}

if (!$jnode_dataset["not_set_database"]) {
	$orderby1 = "";

	if (isset($d_options["domain_sort"])) {
		$jnode_dataset["empty_orderby1"] = false;
		$orderby1 = "`{$d_options["domain_sort"]}` ASC, ";
	}

	if ($jnode_dataset["loaded_pdo"]) {
		$domains_query = <<<"EOT"
SELECT `{$d_options["domain_id"]}`   AS domain_id
     , `{$d_options["domain_name"]}` AS domain_name
  FROM `{$d_options["table_name"]}`
 ORDER BY $orderby1`{$d_options["domain_id"]}` ASC
EOT;

		try {
			$jnode_dataset["domain_list"] = $fixBox->selectRowList(null, $domains_query);
		} catch (\Exception $e) {
			$jnode_dataset["db_error"] = $e->getMessage();

			error_log("FixBox Notice: ".$jnode_dataset["db_error"]);
		}
	}
}