The files that manages score, whitelist and blacklist must be specified as separate files from the SpamAssassin configuration file with include keyword.

The files that manages score, whitelist and blacklist must have write permission for the PHP run account.

Emails that are set in the files that manages whitelist and blacklist are processed only with whitelist_from and blacklist_from, respectively.