#!/bin/bash

cd $1
curl -sL https://repository.rainloop.net/installer.php | php