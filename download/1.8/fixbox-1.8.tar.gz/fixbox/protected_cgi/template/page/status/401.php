<?php
$fixBox  = new \Gurumdari\FixBox();
$i18n = $fixBox->getI18n();

$jnode_dataset = [
	"i18n" => $i18n
];